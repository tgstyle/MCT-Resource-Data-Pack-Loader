RDPL Ore Generation Test Pack (void world)
==========================================

Drop the zip into rdploader/ and make a NEW world. The overworld generates as
empty air with a small stone platform at spawn, and nothing but these three
veins in it. Load this pack on its own: with 'auto' world template selection,
another pack's template can be chosen instead of this one and the world will
not be void.

Fly around. Everything is a solid, obvious block hanging in the air.

    wool_properties   magenta wool, with lime wool mixed in about one block
                      in five. Blobs of 6, y 40 to 90. Tests a placed block
                      chosen by its properties instead of a metadata number,
                      a weighted list, and a random attempt count.

                      WRONG if the wool is white. White is meta 0, which is
                      what you get when the properties are dropped.

    glowstone_baseline
                      glowstone blobs of 8, y 20 to 110. Nothing new is used
                      here, so if this is missing the problem is not in this
                      change set. It also lights the void enough to see by.

    iron_largevein    iron blocks, y 10 to 60, as a large sprawling vein
                      rather than a blob. This is the shape and spread the
                      CoFH World 'fractal' distribution converts into.

WHAT THIS PACK CANNOT SHOW
--------------------------

Replace targets. A vein needs something to replace, and in a void there is
only air, so every entry here replaces minecraft:air. The checks for replace
targets matched by properties, by a meta number, or by the older
"minecraft:stone:3" string all need real terrain, and are in the other test
pack.
