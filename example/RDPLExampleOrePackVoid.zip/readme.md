# RDPL Ore Generation Example (void world)

Drop the zip into `rdploader/` and make a NEW world. The overworld generates
as empty air with a grass platform at the spawn, and nothing but these seven
entries in it. Load this pack on its own: with `auto` world template
selection another pack's template can be chosen instead of this one and the
world will not be void.

Fly around. Everything is a solid, obvious block hanging in the air.

    glowstone_baseline
                      glowstone blobs of 8, y 20 to 110. Nothing beyond the
                      defaults is used, so if this is missing the problem is
                      not in the shapes. It also lights the void enough to
                      see by.

    wool_weighted     magenta wool with lime wool mixed in about one block in
                      five. Blobs of 6, y 40 to 90. A weighted `blocks` list
                      and a random `attempts` range. On this version every
                      wool color is a block of its own, so the list names
                      `minecraft:magenta_wool` and `minecraft:lime_wool`
                      outright.

                      WRONG if the wool is white or one color only.

    log_properties    oak logs lying sideways, half along x and half along z,
                      never upright. Blobs of 6, y 40 to 90. A placed block
                      chosen by its `properties`, which is what a 1.12.2
                      metadata number became.

                      WRONG if a log stands upright: that is the default
                      state, which is what you get when the properties are
                      dropped.

    iron_largevein    iron blocks, y 10 to 60, as a large sprawling vein
                      rather than a blob: the `largevein` shape on the
                      `sprawl` spread.

    basin             packed ice bowls, radius 7 and 4 deep, y 60 to 90.

    spire             gold columns 8 to 14 high tapering to a point, y 100
                      to 130.

    nodule            hollow bone-block shells of radius 3 to 5 (`slim`),
                      y 140 to 170.

## What this pack cannot show

Replace targets. A vein needs something to replace, and in a void there is
only air, so every entry here replaces `minecraft:air`. Replacing by block
name or by a block state with `properties` needs real terrain; the vein
shapes example does that in an ordinary world.
