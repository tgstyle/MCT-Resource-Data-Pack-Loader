MCT Kamikaze Demo
=================

Drop the zip into rdploader/ and make a NEW world. A bedrock arena under
permanent night, inside a 100 block border, with four factions spawning from
the four sides and fighting each other.

The four sides
--------------
Each side is declared in teams/*.json and stands as a vanilla team, so its mobs
are never set against each other: the game refuses to let a mob target anything
on its own team, which is what holds a side together even though this pack lets
any zombie become any of the twelve variants and every spawner emits a mix of
all four sides. The enemies in that mix are fought at once, each side's mobs
wear its color on their names, and every kill scores to the side that made it.

    red      Red Team          zombie_a, sapper_a, cow_a
    blue     Blue Team         zombie_b, sapper_b, rabbit_b
    black    Black Team        zombie_c, sapper_c, wither_skeleton_c
    white    White Team        zombie_d, sapper_d, golem_d

Each faction already targets the other three and the player, which is set in
its own entities/*.json, so the fight starts on its own.

Keeping score
-------------
scoring/kaboom.json holds one objective on the sidebar. A side scores a point
for every mob of another side it kills, and the sidebar shows the four team
totals rather than a row per mob. A round lasts two minutes; the standings
then come up as a card while a cooldown counts down, the map resets to the
welcome, the next round counts in on the action bar, and the side that led
takes the round on the tab list. Three
rounds make a match, whoever won them, and the match's own card closes it
before a fresh one begins.

    /scoreboard players list red     what one side has scored
    /rdpl team                       the four sides and their colors

A server operator can edit teams/*.json or scoring/kaboom.json and run
/rdpl reload to field the change into the running world without restarting.

Watching it
-----------
Stand on the wall or spectate. The arena is lit only by what is in it, so
permanent night is part of the look. Nothing needs starting: the spawners in
functions/arena.mcfunction run as the world is made.

Sounds
------
The scream, the warhead and the firecracker pop in sounds/ were provided by
freesound.org: 339308 by kalibrk, 568877 by fusionwolf3740 and 197044 by
genel, converted to mono Vorbis for the game.
