Mega City Map
=============

A superflat world holding one village laid out from a drawn city map instead
of grown, with sewers under the streets, a subway under those, and a railway
through the town.

What it sets up
---------------
  worldType / generatorOptions   superflat: bedrock, 123 stone, 4 dirt, grass,
                                 plains biome. Surface y64, above sea level, so
                                 nothing bridges or grades, with 128 blocks of
                                 ground under it, which is what the sewers at 8
                                 and the subway at 24 are bored through, in
                                 stone rather than dirt.
  structureAt city=0,0           pins the city to the district at the world
                                 origin, and the map is centered on it.
  villageCitySpacing 32          keeps any second city 32 districts away so it
                                 cannot collide with the first.
  villageLayout                  megavillage:downtown, the map in citymaps/.
                                 Fifteen by ten cells at 48 blocks a cell: #
                                 is a street, + a plaza with its well, a an
                                 alley, and s, B, H and T are shops, blocks,
                                 tall blocks and towers, each rolled from the
                                 three facades by weight. The map turns whole
                                 to one of the four facings from the seed.
  villagePlotsLeast 0            nothing grows past the drawing; the map is the
                                 whole town.
  worldSpawn 0,0                 you spawn in the middle of it.
  worldTime 6000                 noon, locked, so it is always lit for looking at.
  pregenOnNewWorld               not set. The game makes the 12 chunk spawn
                                 floor up front and the rest as you explore.
                                 Set it, 40 makes 81x81 chunks, about 640
                                 blocks out, to have the whole city finished
                                 before you walk into it.

Streets
-------
Roads are nine wide: black concrete with a white edge line down each side, a
yellow center line dashed two on and one off, and two blocks of light gray
sidewalk outside the lines. Alleys are gray, zebra crossings are painted at
junctions, and a dead end closes with a barrier or a sidewalk. Lamp posts
stand on the curb as a structure rather than a stack of blocks
(villagePathLampStructure, street_lamp.nbt in this zip): a five high iron bar
pole, a sea lantern head with an end rod reaching out on each of its four
sides, and an iron cap. A lamp is placed centered on its spot and never
turned, which is why it is the same from every side. make-lamp.py in the Mega
City 32 example writes the file.

Under the streets
-----------------
Every street carries a sewer eight blocks under it (villageSewer*): stone
brick lined, five wide, a water channel down the middle with a chiseled walk
either side, glowstone in the roof every eight blocks, mossy cobblestone
worked into the lining and vines on the walls, and a manhole with a ladder and
a wooden trapdoor where two streets cross.

Two subway lines run under the town at depth 24 (villageSubway*): a stone
brick bore, two tracks of
vanilla rail on gravel and spruce sleepers, a powered rail every sixteen, and
glowstone in the roof. A station sits where each line passes nearest the
plaza and another every 120 blocks where the ground allows, built from
subway_station.nbt, its stair head opening onto the street.
Every line climbs to the surface at one end, beyond the last street over
it, and runs on as an open railway (villageSubwaySurfaces 100).

One railway crosses the whole town on the surface (villageRail*), laid before
the first street so the blocks grow around it: two tracks of vanilla rail on
gravel and spruce sleepers with a gray shoulder each side, a powered rail
every sixteen, running 64 blocks past the last building at either end.
Streets cross it straight through, and a minecart rides the whole of it.

Buildings
---------
The plots the map names are the frame buildings of the Mega City 32 example,
carried in this zip too: each is one template in structures/, baked from the
1.12.2 structure maps that stacked 16 and 32 block frame pieces, and villages/
makes each one a plot. Load this pack without Mega City 32, since both use the
megavillage namespace.

Installing
----------
Drop RDPLExampleCityCustomMap.zip in the rdploader folder on its own and make a
NEW world. The template only applies at world creation. Beside another pack
with a world template, name this one in config/resourcedatapackloader-common.toml:

    worldTemplate = "megavillage:mega_city_map"

What to watch
-------------
The log names every plot the map could not lay: a plot that would overlap a
road or another plot is left open with a line saying so, and so is a plot name
no pack provides.
