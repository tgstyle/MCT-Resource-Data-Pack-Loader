# RDPL Vein Shape Example (void world)

Drop the zip into `rdploader/` and make a NEW world. The overworld is empty
air with a grass platform at the spawn, and the only thing in it is the three
vein shapes, one per pattern, hanging in the open between y 60 and y 140 so
their form can be seen whole. Load this pack on its own: with `auto` world
template selection another pack's template can be chosen instead of this one.

Fly around y 100. Each vein is up to 48 blocks across, one in about four
chunks per entry, with rich / normal / poor tiers:

    plain_vein     pattern default. Iron ore, gold ore at the rich heart,
                   gravel at the poor fringe. A warped blob.
    banded_vein    pattern banded. Coal ore, diamond ore rich, cobblestone
                   poor. Layers stacked every few blocks.
    tube_vein      pattern tube. Lapis ore, emerald ore rich, andesite poor.
                   Hollow tubes winding up through the open air.

`/rdplserver vein plain_vein` says where the nearest veins are seeded, whether
or not those chunks exist yet.

WRONG if a vein ends flat at a chunk edge, if the rich block appears outside
a vein, or if two chunks disagree about where a vein is.
