#!/usr/bin/env python3
"""Write street_lamp.nbt, the lamp post the Mega City templates stand on every curb.

    make-lamp.py <out.nbt>

A 3 by 7 by 3 structure template the game's StructureTemplateManager reads:
a five high iron bar pole, a sea lantern head with an end rod reaching out on
each of its four sides, and an iron trapdoor as a cap. Only the lamp's own
cells are written, so the curb and the road around it are left as they are.
The lamp is placed centered on its spot and never turned, which is why it is
the same from every side. Needs nbtlib (pip install nbtlib).
"""
import sys
from nbtlib import File, Compound, List, Int, String


def state(name, **props):
    tag = Compound({'Name': String(name)})
    if props:
        tag['Properties'] = Compound({k: String(v) for k, v in props.items()})
    return tag


def main():
    out = sys.argv[1]
    palette = [
        state('minecraft:iron_bars'),
        state('minecraft:sea_lantern'),
        state('minecraft:end_rod', facing='west'),
        state('minecraft:end_rod', facing='east'),
        state('minecraft:end_rod', facing='north'),
        state('minecraft:end_rod', facing='south'),
        state('minecraft:iron_trapdoor', facing='north', half='bottom', open='false'),
    ]
    cells = [((1, y, 1), 0) for y in range(5)]
    cells += [((1, 5, 1), 1), ((0, 5, 1), 2), ((2, 5, 1), 3), ((1, 5, 0), 4), ((1, 5, 2), 5), ((1, 6, 1), 6)]
    blocks = [Compound({'pos': List[Int]([Int(v) for v in pos]), 'state': Int(index)}) for pos, index in cells]
    root = Compound({
        'size': List[Int]([Int(3), Int(7), Int(3)]),
        'palette': List[Compound](palette),
        'blocks': List[Compound](blocks),
        'entities': List[Compound]([]),
        'DataVersion': Int(1343),
    })
    File(root, gzipped=True).save(out)
    print('wrote', out, len(blocks), 'block(s)')


if __name__ == '__main__':
    main()
