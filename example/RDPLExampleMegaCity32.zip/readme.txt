Mega City 32
============

A superflat world holding one deliberately enormous village, for watching how
the street generator behaves with no terrain fighting it, with sewers under
the streets, a subway under those, and a railway through the town.

What it sets up
---------------
  worldType / generatorOptions   superflat: bedrock, 59 stone, 4 dirt, grass,
                                 plains biome, villages enabled. Surface y64,
                                 above sea level, so nothing bridges or grades,
                                 with 60 blocks of ground under it, which is
                                 what the sewers at 8 and the subway at 24 are
                                 bored through, in stone rather than dirt.
  structureAt villages=0,0       pins the village to the world origin, bypassing
                                 spacing, separation and flat-ground checks.
  structureSpacing villages=256  keeps any second village 4096 blocks away so it
                                 cannot collide with the first.
  villagePlotsLeast 1000         the size to grow to. villagePlotsMost 0 lifts
                                 the ceiling so nothing stops it early.
  worldSpawn 0,0                 you spawn in the middle of it.
  worldTime 6000                 noon, locked, so it is always lit for looking at.
  pregenOnNewWorld               not set. The game makes the 12 chunk spawn
                                 floor up front and the rest as you explore.
                                 Set it, 40 makes 81x81 chunks, about 640
                                 blocks out, to have the whole city finished
                                 before you walk into it.

Streets
-------
Roads are nine wide: black concrete with a white edge line down each side, a
yellow center line dashed two on and one off, and two blocks of light gray
sidewalk outside the lines. Alleys are gray, zebra crossings are painted at
junctions, and a dead end closes with a barrier or a sidewalk. Lamp posts
stand on the curb as a structure rather than a stack of blocks
(villagePathLampStructure, street_lamp.nbt in this zip): a five high iron bar
pole, a sea lantern head with an end rod reaching out on each of its four
sides, and an iron cap. A lamp is placed centered on its spot and never
turned, which is why it is the same from every side. make-lamp.py in the Mega
City 32 example writes the file.

Under the streets
-----------------
Every street carries a sewer eight blocks under it (villageSewer*): stone
brick lined, five wide, a water channel down the middle with a chiseled walk
either side, glowstone in the roof every eight blocks, mossy cobblestone
worked into the lining and vines on the walls, and a manhole with a ladder and
a wooden trapdoor where two streets cross.

Two subway lines run under the town at depth 24 (villageSubway*): a stone
brick bore in a mix of plain, cracked, mossy and chiseled, two tracks of
vanilla rail on gravel and spruce sleepers, a powered rail every sixteen, and
glowstone in the roof. A station sits where each line passes nearest the
plaza and another every 120 blocks where the ground allows, built from
subway_station.nbt with subway_entrance.nbt marking the way in on the street.
Every line climbs to the surface at one end, beyond the last street over
it, and runs on as an open railway (villageSubwaySurfaces 100).

One railway crosses the whole town on the surface (villageRail*), laid before
the first street so the blocks grow around it: two tracks of vanilla rail on
gravel and spruce sleepers with a gray shoulder each side, a powered rail
every sixteen, running 64 blocks past the last building at either end.
Streets cross it straight through, and a minecart rides the whole of it.

Buildings
---------
The buildings are structure maps rather than vanilla houses (villagePieces
blacklists all nine vanilla house and farm pieces). Twelve maps compose frame
buildings from small NBT templates: four sizes, from 16x16 shops through 32x32
blocks and tall blocks up to 32x32 towers 128 high, each in three facade
styles - light blue glass, gray glass, and white concrete panels with window
bands. The village def roll picks size and style per building, so the skyline
mixes itself.

Installing
----------
Drop RDPLExampleMegaCity32.zip in the rdploader folder and make a NEW world.
The template only applies at world creation.

What to watch
-------------
villagePlotsLeast is an ask, not a promise: the log line "grew N district(s) to
N plot(s) against the asked minimum of 1000" says what it actually reached.
Growth marches out by district hops and scales its reach with plot size, so the
full 1000 seats even at these footprints - a fresh world lands a little over
the ask, a bit under a kilometer and a half across.
