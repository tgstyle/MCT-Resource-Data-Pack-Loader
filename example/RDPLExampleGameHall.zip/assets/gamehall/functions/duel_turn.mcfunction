function gamehall:duel_you
function gamehall:duel_house
