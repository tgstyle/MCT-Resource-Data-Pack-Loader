scoreboard players tag @e[type=armor_stand,tag=ghdemo] remove ghchess
scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghwaitchess
execute @p ~ ~ ~ fill ~-1 ~ ~-11 ~14 ~30 ~-2 minecraft:air
execute @p ~ ~ ~ fill ~-1 ~-1 ~-11 ~14 ~-1 ~-2 minecraft:stone 0
execute @p ~ ~ ~ rdplserver game board end hall
execute @p ~ ~ ~ rdplserver game board start chess hall ~3 ~ ~-10
tp @p ~ ~ ~ -135 20
tellraw @a ["",{"text":"Hall 9/9 ","color":"gold"},{"text":"Chess, on a cleared pad in front of you to the north east, with snow golems against zombies: "},{"text":"/rdplserver game board start chess hall","color":"aqua"}]
tellraw @a ["",{"text":"The computer plays White and Black at level 2, and the tour ends once the game is won or drawn: "},{"text":"/rdplserver game board ai hall White 2","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game board ai hall White 2
execute @p ~ ~ ~ rdplserver game board ai hall Black 2
