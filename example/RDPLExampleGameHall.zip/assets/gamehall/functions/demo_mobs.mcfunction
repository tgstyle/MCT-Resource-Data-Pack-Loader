scoreboard players tag @e[type=armor_stand,tag=ghdemo] remove ghmobs
scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghfortune
summon area_effect_cloud 0 250 0 {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Demo 5/7 ","color":"gold"},{"text":"A card from the mobs deck, which reshuffles itself when it runs out: "},{"text":"/rdplserver game deck draw mobs","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game deck draw mobs
