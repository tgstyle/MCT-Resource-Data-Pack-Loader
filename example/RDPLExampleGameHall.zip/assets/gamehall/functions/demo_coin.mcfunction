scoreboard players tag @e[type=armor_stand,tag=ghdemo] remove ghcoin
scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghd20
summon area_effect_cloud 0 250 0 {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Hall 1/9 ","color":"gold"},{"text":"A coin toss, in the pack's own wording: "},{"text":"/rdplserver game coin","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game coin
