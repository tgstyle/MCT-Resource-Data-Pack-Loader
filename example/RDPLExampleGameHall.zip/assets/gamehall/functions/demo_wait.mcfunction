kill @e[type=armor_stand,tag=ghdemo]
kill @e[type=area_effect_cloud,tag=ghdemo]
summon armor_stand 0 250 0 {Tags:["ghdemo","ghstart"],Marker:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b}
summon area_effect_cloud 0 250 0 {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:100}
