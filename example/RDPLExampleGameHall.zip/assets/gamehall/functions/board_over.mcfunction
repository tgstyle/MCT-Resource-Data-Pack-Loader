execute @e[type=armor_stand,tag=ghwaitcheckers] ~ ~ ~ summon area_effect_cloud ~ ~ ~ {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:80}
scoreboard players tag @e[type=armor_stand,tag=ghwaitcheckers] add ghchess
scoreboard players tag @e[type=armor_stand,tag=ghchess] remove ghwaitcheckers
execute @e[type=armor_stand,tag=ghwaitchess] ~ ~ ~ summon area_effect_cloud ~ ~ ~ {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:80}
scoreboard players tag @e[type=armor_stand,tag=ghwaitchess] add ghend
scoreboard players tag @e[type=armor_stand,tag=ghend] remove ghwaitchess
