scoreboard players tag @e[type=armor_stand,tag=ghdemo] remove ghfortune
scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghduel
summon area_effect_cloud 0 250 0 {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Demo 6/7 ","color":"gold"},{"text":"A card from the fortune deck, which stays empty until shuffled: "},{"text":"/rdplserver game deck draw fortune","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game deck draw fortune
