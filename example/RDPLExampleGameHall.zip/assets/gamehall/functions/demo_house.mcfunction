scoreboard players tag @e[type=armor_stand,tag=ghdemo] remove ghturnhouse
summon area_effect_cloud 0 250 0 {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:80}
execute @p ~ ~ ~ function gamehall:duel_house
execute @p[score_ghturn=2] ~ ~ ~ scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghturnyou
execute @p[score_ghturn_min=3] ~ ~ ~ scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghend
