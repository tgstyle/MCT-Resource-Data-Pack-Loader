tellraw @a ["",{"text":"Turn ","color":"gold"},{"score":{"name":"@p","objective":"ghturn"},"color":"gold"},{"text":" of 3: ","color":"gold"},{"text":"the House rolls."}]
execute @p ~ ~ ~ rdplserver game die 6 store ghhouse audience silent
tellraw @a ["",{"text":"The House rolled a "},{"score":{"name":"@p","objective":"ghhouse"}},{"text":"."}]
scoreboard players operation @p ghyou -= @p ghhouse
execute @p[score_ghyou_min=1] ~ ~ ~ scoreboard players add @p duel 1
execute @p[score_ghyou=-1] ~ ~ ~ scoreboard players add House duel 1
execute @p[score_ghyou_min=1] ~ ~ ~ tellraw @a ["",{"selector":"@p"},{"text":" rolled higher and scores. "},{"text":"Score: ","color":"gold"},{"selector":"@p"},{"text":" "},{"score":{"name":"@p","objective":"duel"}},{"text":", House "},{"score":{"name":"House","objective":"duel"}}]
execute @p[score_ghyou=-1] ~ ~ ~ tellraw @a ["",{"text":"The House rolled higher and scores. "},{"text":"Score: ","color":"gold"},{"selector":"@p"},{"text":" "},{"score":{"name":"@p","objective":"duel"}},{"text":", House "},{"score":{"name":"House","objective":"duel"}}]
execute @p[score_ghyou_min=0,score_ghyou=0] ~ ~ ~ tellraw @a ["",{"text":"Level rolls, so nobody scores. "},{"text":"Score: ","color":"gold"},{"selector":"@p"},{"text":" "},{"score":{"name":"@p","objective":"duel"}},{"text":", House "},{"score":{"name":"House","objective":"duel"}}]
execute @p[score_ghturn_min=3] ~ ~ ~ function gamehall:duel_result
