scoreboard players tag @e[type=armor_stand,tag=ghdemo] remove ghcheckers
scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghwaitcheckers
execute @p ~ ~ ~ fill ~-1 ~ ~2 ~14 ~30 ~11 minecraft:air
execute @p ~ ~ ~ fill ~-1 ~-1 ~2 ~14 ~-1 ~11 minecraft:stone 0
execute @p ~ ~ ~ rdplserver game board end table
execute @p ~ ~ ~ rdplserver game board start checkers table ~3 ~ ~3
tp @p ~ ~ ~ -45 20
tellraw @a ["",{"text":"Hall 8/9 ","color":"gold"},{"text":"Checkers, on a cleared pad in front of you to the south east, with sheep and pigs: "},{"text":"/rdplserver game board start checkers table","color":"aqua"}]
tellraw @a ["",{"text":"The computer plays both sides, a move every second or so, and the tour goes on once the game is won or drawn: "},{"text":"/rdplserver game board ai table Light 1","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game board ai table Light 1
execute @p ~ ~ ~ rdplserver game board ai table Dark 1
