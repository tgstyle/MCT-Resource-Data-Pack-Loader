scoreboard players tag @e[type=armor_stand,tag=ghdemo] remove ghdice
scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghmobs
summon area_effect_cloud 0 250 0 {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Demo 4/7 ","color":"gold"},{"text":"Two six-sided dice plus one, each die shown: "},{"text":"/rdplserver game dice 2d6+1","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game dice 2d6+1
