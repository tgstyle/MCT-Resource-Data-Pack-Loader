scoreboard objectives add ghyou dummy
scoreboard objectives add ghhouse dummy
scoreboard objectives add ghturn dummy
scoreboard players add @p ghturn 0
scoreboard players add @p duel 0
scoreboard players add House duel 0
execute @p[score_ghturn_min=3] ~ ~ ~ tellraw @a ["",{"text":"This Duel is over. ","color":"gold"},{"text":"/function gamehall:duel","color":"aqua"},{"text":" starts another."}]
execute @p[score_ghturn=2] ~ ~ ~ function gamehall:duel_turn
