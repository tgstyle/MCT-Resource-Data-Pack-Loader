scoreboard objectives add ghyou dummy
scoreboard objectives add ghhouse dummy
scoreboard objectives add ghturn dummy
scoreboard players set @p duel 0
scoreboard players set House duel 0
scoreboard players set @p ghturn 0
tellraw @a ["",{"text":"Duel: ","color":"gold"},{"selector":"@p"},{"text":" against the House over three turns. Each turn both sides roll 1d6, and the higher roll scores a point."}]
