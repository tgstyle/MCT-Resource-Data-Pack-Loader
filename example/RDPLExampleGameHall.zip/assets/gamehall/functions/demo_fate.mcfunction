scoreboard players tag @e[type=armor_stand,tag=ghdemo] remove ghfate
scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghdice
summon area_effect_cloud 0 250 0 {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Demo 3/7 ","color":"gold"},{"text":"The pack's weighted fate die: "},{"text":"/rdplserver game die fate","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game die fate
