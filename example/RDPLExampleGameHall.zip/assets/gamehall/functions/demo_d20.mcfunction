scoreboard players tag @e[type=armor_stand,tag=ghdemo] remove ghd20
scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghfate
summon area_effect_cloud 0 250 0 {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Demo 2/7 ","color":"gold"},{"text":"One twenty-sided die: "},{"text":"/rdplserver game die 20","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game die 20
