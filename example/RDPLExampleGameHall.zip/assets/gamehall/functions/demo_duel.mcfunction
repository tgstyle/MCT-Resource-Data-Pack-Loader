scoreboard players tag @e[type=armor_stand,tag=ghdemo] remove ghduel
scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghturnyou
summon area_effect_cloud 0 250 0 {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Demo 7/7 ","color":"gold"},{"text":"A Duel against the House, played out turn by turn: "},{"text":"/function gamehall:duel","color":"aqua"}]
execute @p ~ ~ ~ function gamehall:duel
