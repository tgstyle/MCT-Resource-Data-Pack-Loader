scoreboard players tag @e[type=armor_stand,tag=ghdemo] remove ghturnyou
scoreboard players tag @e[type=armor_stand,tag=ghdemo] add ghturnhouse
summon area_effect_cloud 0 250 0 {Tags:["ghdemo"],Radius:0.0f,WaitTime:0,Duration:80}
execute @p ~ ~ ~ function gamehall:duel_you
