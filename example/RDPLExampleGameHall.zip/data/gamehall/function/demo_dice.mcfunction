tellraw @a ["",{"text":"Hall 4/9 ","color":"gold"},{"text":"Two six-sided dice plus one, each die shown: "},{"text":"/rdplserver game dice 2d6+1","color":"aqua"}]
execute as @p at @s run rdplserver game dice 2d6+1
schedule function gamehall:demo_mobs 4s
