tellraw @a ["",{"text":"Hall 3/9 ","color":"gold"},{"text":"The pack's weighted fate die: "},{"text":"/rdplserver game die fate","color":"aqua"}]
execute as @p at @s run rdplserver game die fate
schedule function gamehall:demo_dice 4s
