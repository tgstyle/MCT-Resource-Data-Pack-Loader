scoreboard objectives add ghyou dummy
scoreboard objectives add ghhouse dummy
scoreboard objectives add ghturn dummy
scoreboard players add @p ghturn 0
scoreboard players add @p duel 0
scoreboard players add House duel 0
execute if entity @p[scores={ghturn=3..}] run tellraw @a ["",{"text":"This Duel is over. ","color":"gold"},{"text":"/function gamehall:duel","color":"aqua"},{"text":" starts another."}]
execute if entity @p[scores={ghturn=..2}] run function gamehall:duel_turn
