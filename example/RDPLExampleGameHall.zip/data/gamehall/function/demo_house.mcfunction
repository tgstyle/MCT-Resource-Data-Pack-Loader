execute as @p at @s run function gamehall:duel_house
execute if entity @p[scores={ghturn=..2}] run schedule function gamehall:demo_you 4s
execute if entity @p[scores={ghturn=3..}] run schedule function gamehall:demo_checkers 4s
