tellraw @a ["",{"text":"Demo 2/7 ","color":"gold"},{"text":"One twenty-sided die: "},{"text":"/rdplserver game die 20","color":"aqua"}]
execute as @p at @s run rdplserver game die 20
schedule function gamehall:demo_fate 4s
