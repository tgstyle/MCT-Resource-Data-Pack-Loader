scoreboard players operation @p ghyou = @p duel
scoreboard players operation @p ghyou -= House duel
execute if entity @p[scores={ghyou=1..}] run tellraw @a ["",{"text":"Winner: ","color":"gold"},{"selector":"@p"},{"text":" takes the Duel "},{"score":{"name":"@p","objective":"duel"}},{"text":" to "},{"score":{"name":"House","objective":"duel"}},{"text":"."}]
execute if entity @p[scores={ghyou=..-1}] run tellraw @a ["",{"text":"Winner: ","color":"gold"},{"text":"the House takes the Duel "},{"score":{"name":"House","objective":"duel"}},{"text":" to "},{"score":{"name":"@p","objective":"duel"}},{"text":"."}]
execute if entity @p[scores={ghyou=0}] run tellraw @a ["",{"text":"Level at ","color":"gold"},{"score":{"name":"@p","objective":"duel"},"color":"gold"},{"text":" to ","color":"gold"},{"score":{"name":"House","objective":"duel"},"color":"gold"},{"text":", so a tiebreak draw picks the winner: "},{"text":"/rdplserver game tiebreak duel","color":"aqua"}]
execute if entity @p[scores={ghyou=0}] as @p at @s run rdplserver game tiebreak duel
