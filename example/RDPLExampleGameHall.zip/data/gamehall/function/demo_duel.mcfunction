tellraw @a ["",{"text":"Hall 7/9 ","color":"gold"},{"text":"A Duel against the House, played out turn by turn: "},{"text":"/function gamehall:duel","color":"aqua"}]
execute as @p at @s run function gamehall:duel
schedule function gamehall:demo_you 4s
