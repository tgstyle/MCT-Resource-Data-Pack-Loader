tellraw @a ["",{"text":"Demo 7/7 ","color":"gold"},{"text":"A Duel against the House, played out turn by turn: "},{"text":"/function gamehall:duel","color":"aqua"}]
execute as @p at @s run function gamehall:duel
schedule function gamehall:demo_you 4s
