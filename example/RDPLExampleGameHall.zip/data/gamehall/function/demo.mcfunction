schedule clear gamehall:demo_coin
schedule clear gamehall:demo_d20
schedule clear gamehall:demo_fate
schedule clear gamehall:demo_dice
schedule clear gamehall:demo_mobs
schedule clear gamehall:demo_fortune
schedule clear gamehall:demo_duel
schedule clear gamehall:demo_you
schedule clear gamehall:demo_house
schedule clear gamehall:demo_end
tellraw @a ["",{"text":"Game Hall demo: ","color":"gold"},{"text":"the hall now runs its own commands, one every four seconds. Watch the chat."}]
schedule function gamehall:demo_coin 5s
