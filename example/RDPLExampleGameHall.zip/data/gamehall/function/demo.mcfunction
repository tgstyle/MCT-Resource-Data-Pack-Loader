schedule clear gamehall:demo_coin
schedule clear gamehall:demo_d20
schedule clear gamehall:demo_fate
schedule clear gamehall:demo_dice
schedule clear gamehall:demo_mobs
schedule clear gamehall:demo_fortune
schedule clear gamehall:demo_duel
schedule clear gamehall:demo_you
schedule clear gamehall:demo_house
schedule clear gamehall:demo_checkers
schedule clear gamehall:demo_chess
schedule clear gamehall:demo_end
scoreboard objectives add ghdemo dummy
scoreboard players set #wait ghdemo 0
tellraw @a ["",{"text":"Game Hall tour: ","color":"gold"},{"text":"the hall now runs its own commands, one every four seconds, each after a line naming it, then lays out checkers and chess and lets the computer play each game to its end. Watch the chat."}]
schedule function gamehall:demo_coin 5s
