tellraw @a ["",{"text":"Hall 5/9 ","color":"gold"},{"text":"A card from the mobs deck, which reshuffles itself when it runs out: "},{"text":"/rdplserver game deck draw mobs","color":"aqua"}]
execute as @p at @s run rdplserver game deck draw mobs
schedule function gamehall:demo_fortune 4s
