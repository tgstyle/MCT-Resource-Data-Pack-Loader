tellraw @a ["",{"text":"Demo 6/7 ","color":"gold"},{"text":"A card from the fortune deck, which stays empty until shuffled: "},{"text":"/rdplserver game deck draw fortune","color":"aqua"}]
execute as @p at @s run rdplserver game deck draw fortune
schedule function gamehall:demo_duel 4s
