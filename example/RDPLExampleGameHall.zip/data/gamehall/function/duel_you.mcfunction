scoreboard players add @p ghturn 1
tellraw @a ["",{"text":"Turn ","color":"gold"},{"score":{"name":"@p","objective":"ghturn"},"color":"gold"},{"text":" of 3: ","color":"gold"},{"selector":"@p"},{"text":" rolls."}]
execute as @p at @s run rdplserver game die 6 store ghyou
