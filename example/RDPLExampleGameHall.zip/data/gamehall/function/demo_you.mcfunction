execute as @p at @s run function gamehall:duel_you
schedule function gamehall:demo_house 4s
