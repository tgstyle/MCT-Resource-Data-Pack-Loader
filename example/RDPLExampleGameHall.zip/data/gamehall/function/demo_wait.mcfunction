schedule function gamehall:demo 5s
