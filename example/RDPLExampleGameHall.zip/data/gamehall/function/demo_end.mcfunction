tellraw @a ["",{"text":"Demo over. ","color":"gold"},{"text":"Play the Duel yourself: "},{"text":"/function gamehall:duel","color":"aqua"},{"text":" starts one, and each "},{"text":"/function gamehall:duel_roll","color":"aqua"},{"text":" takes your turn, which the House answers with its own."}]
tellraw @a ["",{"text":"/function gamehall:demo","color":"aqua"},{"text":" plays the demo again."}]
