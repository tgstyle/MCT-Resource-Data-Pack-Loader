tellraw @a ["",{"text":"Turn ","color":"gold"},{"score":{"name":"@p","objective":"ghturn"},"color":"gold"},{"text":" of 3: ","color":"gold"},{"text":"the House rolls."}]
execute as @p at @s run rdplserver game die 6 store ghhouse audience silent
tellraw @a ["",{"text":"The House rolled a "},{"score":{"name":"@p","objective":"ghhouse"}},{"text":"."}]
scoreboard players operation @p ghyou -= @p ghhouse
execute if entity @p[scores={ghyou=1..}] run scoreboard players add @p duel 1
execute if entity @p[scores={ghyou=..-1}] run scoreboard players add House duel 1
execute if entity @p[scores={ghyou=1..}] run tellraw @a ["",{"selector":"@p"},{"text":" rolled higher and scores. "},{"text":"Score: ","color":"gold"},{"selector":"@p"},{"text":" "},{"score":{"name":"@p","objective":"duel"}},{"text":", House "},{"score":{"name":"House","objective":"duel"}}]
execute if entity @p[scores={ghyou=..-1}] run tellraw @a ["",{"text":"The House rolled higher and scores. "},{"text":"Score: ","color":"gold"},{"selector":"@p"},{"text":" "},{"score":{"name":"@p","objective":"duel"}},{"text":", House "},{"score":{"name":"House","objective":"duel"}}]
execute if entity @p[scores={ghyou=0}] run tellraw @a ["",{"text":"Level rolls, so nobody scores. "},{"text":"Score: ","color":"gold"},{"selector":"@p"},{"text":" "},{"score":{"name":"@p","objective":"duel"}},{"text":", House "},{"score":{"name":"House","objective":"duel"}}]
execute if entity @p[scores={ghturn=3..}] run function gamehall:duel_result
