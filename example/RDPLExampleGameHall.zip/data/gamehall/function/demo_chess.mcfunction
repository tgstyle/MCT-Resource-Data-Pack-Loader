execute at @p run fill ~-1 ~ ~-11 ~14 ~30 ~-2 minecraft:air
execute at @p run fill ~-1 ~-1 ~-11 ~14 ~-1 ~-2 minecraft:stone
rdplserver game board end hall
execute as @p at @s run rdplserver game board start chess hall ~3 ~ ~-10
execute as @p at @s run tp @s ~ ~ ~ -135 20
tellraw @a ["",{"text":"Hall 9/9 ","color":"gold"},{"text":"Chess, on a cleared pad in front of you to the north east, with snow golems against zombies: "},{"text":"/rdplserver game board start chess hall","color":"aqua"}]
tellraw @a ["",{"text":"The computer plays White and Black at level 2, and the tour ends once the game is won or drawn: "},{"text":"/rdplserver game board ai hall White 2","color":"aqua"}]
rdplserver game board ai hall White 2
rdplserver game board ai hall Black 2
scoreboard players set #wait ghdemo 2
