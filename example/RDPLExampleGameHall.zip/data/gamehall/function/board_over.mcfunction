execute if score #wait ghdemo matches 1 run schedule function gamehall:demo_chess 4s
execute if score #wait ghdemo matches 2 run schedule function gamehall:demo_end 4s
scoreboard players set #wait ghdemo 0
