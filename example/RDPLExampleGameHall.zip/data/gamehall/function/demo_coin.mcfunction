tellraw @a ["",{"text":"Hall 1/9 ","color":"gold"},{"text":"A coin toss, in the pack's own wording: "},{"text":"/rdplserver game coin","color":"aqua"}]
execute as @p at @s run rdplserver game coin
schedule function gamehall:demo_d20 4s
