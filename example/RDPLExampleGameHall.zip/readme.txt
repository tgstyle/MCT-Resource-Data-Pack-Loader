RDPL Game Hall Example
======================

Drop the zip into rdploader/ and make a NEW world. Load this pack on its
own: with 'auto' world template selection another pack's template can be
chosen instead of this one.

The world is flat and creative, held at noon on easy difficulty, with no
natural spawns and mob griefing off, so the snow golem pawns leave no snow
on the chess board. The Dice Cup is in the RDPL Game Hall Example creative
tab. Every roll and draw below is an ordinary chat line
built on the server, so a player without the mod reads it too.

The tour
--------

When you close the world intro, or at your first login when the intro is
skipped, the hall waits five seconds and then runs its own commands in
chat, one every four seconds, each after a line numbered Hall 1/9 to
Hall 9/9: a coin, a d20, the fate die and 2d6+1, a draw from each deck,
a whole Duel against the House, played out turn by turn with the score
after each turn and the winner at the end, and then checkers and chess.
Each board goes on a pad the tour clears and floors with stone, it turns
you to face the board, and the computer plays both sides, a move about
every second; the tour goes on only once the game is won or drawn, and
ends with "Tour over.". It plays once per world.

    /function gamehall:demo     plays it again

Rolling and drawing
-------------------

    /rdplserver game coin                 heads or tails, in the pack's
                                          own wording
    /rdplserver game die 20               one twenty-sided die
    /rdplserver game die fate             a pack die, by its weights
    /rdplserver game dice 2d6+1           dice added up, each one shown
    /rdplserver game advantage 1d20       roll twice, keep the higher
    /rdplserver game deck draw mobs       a card from what is left
    /rdplserver game deck left fortune    how many cards remain
    /rdplserver game deck shuffle fortune put every card back
    /rdplserver game last                 the latest rolls

Any roll can end with "store <objective>" to keep its number as a score,
or "audience self" to roll in private.

The Duel
--------

A Duel is three turns against the House, kept on the Duel objective on
the sidebar. In each turn you roll 1d6, then the House rolls its own, and
the higher roll scores a point. After the third turn the higher score
wins; a level score is settled by a tiebreak draw. Nothing runs until you
start it.

    /function gamehall:duel         starts a Duel, both scores at 0
    /function gamehall:duel_roll    takes your turn, and the House answers
    /rdplserver game tiebreak duel  draws one of the sides level at the
                                    top of the Duel

Boards
------

    /rdplserver game board start chess hall
    /rdplserver game board start checkers table

Each lays a board one block down where you stand and fills it with mobs.
Right-click one of your pieces to see where it can go, then right-click
the square or the piece to take. The first player to move a side holds
it; the computer plays the other, at level 2 for chess and level 1 for
checkers. A finished game pays Board points shown under each player's
name: 3 for a win, 1 for a draw, -1 for a loss.

    /rdplserver game board show hall          the position as letters
    /rdplserver game board move hall e2 e4    a move by square names
    /rdplserver game board resign hall
    /rdplserver game board draw hall
    /rdplserver game board takeback hall
    /rdplserver game board ai hall Black 4    a stronger computer
    /rdplserver game board end hall           clears the board

What each part of the pack shows
--------------------------------

    dice/hall.json    Two weighted dice (fate and weather), a mobs deck
                      that reshuffles itself when it runs out, and a
                      fortune deck with "reshuffle": false that stays
                      empty until shuffled. "says" rewords the coin and
                      the pack die lines.

    items/dice_cup.json
                      A plain item. "rolls" makes a right-click roll as
                      the command does, with a two second cooldown. Its
                      icon is a pixel map in textures/items/.

    scoring/duel.json The Duel objective on the sidebar. "tiebreak" makes
                      it the one a bare /rdplserver game tiebreak draws
                      on. It has no "turns", so no turn clock runs while
                      nobody plays.

    scoring/boardwins.json
                      The objective the two board games pay into.

    games/chess.json, games/checkers.json
                      Each board game in one file: the board and its
                      squares, the two sides, every piece with its mobs
                      and its moves, the starting position, the draw
                      rules, a chess clock and the computer's level.
                      Checkers shows hops, forced and chained captures,
                      and a man promoted to a king.

    functions/duel*.mcfunction
                      The Duel. duel makes its objectives and sets both
                      scores to 0. duel_you counts the turn and rolls
                      1d6 as the nearest player with "store ghyou";
                      duel_house rolls the House's die with "store
                      ghhouse audience silent", says it, scores the
                      higher roll and, after the third turn, runs
                      duel_result, which names the winner or runs the
                      tiebreak. duel_roll plays one whole turn.

    cards/demo.json, functions/demo*.mcfunction, gamerules/game_hall.json
                      The demo. The card fires on first_join, which
                      comes when the player closes the world intro, or
                      at login when the intro is skipped; "once_per_world"
                      plays it once per world. Its "runs" calls
                      demo_wait, which leaves a marker armor stand above
                      spawn and a five second timer cloud. The game rule
                      gameLoopFunction runs demo_tick every tick, which
                      starts functions/demo.mcfunction when that cloud
                      runs out; it sets the next cloud. demo_tick moves
                      to the next step each time
                      the cloud runs out; each step names itself in
                      chat, then runs its command as the nearest player.
                      The Duel's steps alternate demo_you and demo_house
                      until the third turn. demo_checkers and demo_chess
                      fill a pad with air 30 blocks up and a stone floor,
                      start the board on it, tp you to face it and set
                      the computer on both sides; the marker stand then
                      waits until the game ends.

    rdpl/cards/board_result.json, functions/board_over.mcfunction
                      The built-in board result card, shown in chat. Its
                      "runs" calls board_over, which moves a waiting tour
                      on to the next step and does nothing otherwise.

    worldintro/game_hall.json, texts/
                      Three still pages shown the first time a player
                      enters the world: the tour, rolls and the Duel,
                      and the boards.
