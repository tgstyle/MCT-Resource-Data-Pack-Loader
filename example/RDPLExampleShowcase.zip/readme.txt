RDPL Showcase

One zip that loads on 1.12.2, 1.20.1 and 1.21.1 of Resource Data Pack Loader.
Put it in the rdploader folder and start a new world.

How it is laid out:

  assets/showcase/        shared by every version: the intro texts and the pictures
  data/showcase/          the definitions 1.20.1 and 1.21.1 read: cards, the intro,
                          the disabled list and the world templates
  config/options.json     the pack options, welcomeAsCard and welcomeAsNote
  versions/1.12.2/        what only 1.12.2 reads: the same definitions under assets/,
                          the tick function and the game rule that runs it
  versions/1.20.1/        the tick function in the 1.20.1 folder names
  versions/1.21.1/        the tick function in the 1.21.1 folder names

A file in the running version's folder is read in place of the same path at the
root, and another version's folder is never read.

What it shows:

  cards/first_join_center_panel.json      first join, center card, panel on, rdpl_bold
  cards/biome_enter_corner_no_panel.json  entering an ocean or a river, corner card, no panel, rdpl_italic
  cards/y_level_corner_image.json         above y 100, corner card over a PNG, rdpl_runic
  cards/play_time_center_runes.json       one minute played, center card, no panel, Unicode runes
  cards/respawn_corner_panel.json         a respawn, corner card, panel on, rdpl
  cards/command_center_image.json         /rdplserver card showcase:command_center_image, center card over a PNG
  disabled/tnt_and_ender_pearls.json      a disabled block and a disabled item
  worldintro/showcase_intro.json          a still page of instructions, then a scrolling story
  worldtemplates/welcome_as_card.json     seed, difficulty, game mode, motd and the welcome card
  worldtemplates/welcome_as_note.json     the same world with the welcome as a note and no panel

To see the welcome as a note, set welcomeAsCard to false and welcomeAsNote to true in
rdploader/config/RDPLExampleShowcase.json and restart.
