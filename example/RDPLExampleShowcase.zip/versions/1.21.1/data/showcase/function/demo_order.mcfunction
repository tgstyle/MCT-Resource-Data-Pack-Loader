tellraw @a ["",{"text":"Games 5/7 ","color":"gold"},{"text":"A work order, 3 blocks north west: a chest with a spare iron pickaxe, iron ore past it, and a Miner. Put a sign on the chest with Dig on its first line, and the Miner digs the ore into it."}]
execute at @p run setblock ~-3 ~ ~-3 minecraft:chest{Items:[{Slot:0b,id:"minecraft:iron_pickaxe",count:1}]}
execute at @p run fill ~-6 ~ ~-6 ~-5 ~1 ~-5 minecraft:iron_ore
execute at @p run summon showcase:miner ~-3 ~ ~-1 {HandItems:[{id:"minecraft:iron_pickaxe",count:1},{}]}
schedule function showcase:demo_board 4s
