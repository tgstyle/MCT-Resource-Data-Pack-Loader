gamemode creative @s
tag @s add rdpl_creative
