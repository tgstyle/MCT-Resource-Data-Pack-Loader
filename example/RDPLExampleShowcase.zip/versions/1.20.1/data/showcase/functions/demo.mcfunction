schedule clear showcase:demo_die
schedule clear showcase:demo_deck
schedule clear showcase:demo_turns
schedule clear showcase:demo_tie
schedule clear showcase:demo_order
schedule clear showcase:demo_board
schedule clear showcase:demo_move
schedule clear showcase:demo_end
schedule clear showcase:demo_command
schedule clear showcase:demo_high
schedule clear showcase:demo_water
schedule clear showcase:demo_respawn
scoreboard objectives add scdemo dummy
scoreboard players set #wait scdemo 0
scoreboard objectives add scdown dummy
scoreboard players reset @a scdown
tellraw @a ["",{"text":"Showcase games: ","color":"gold"},{"text":"the Showcase now runs its own commands, one every four seconds, each after a line naming it, and plays a whole game of checkers before it ends. Watch the chat."}]
schedule function showcase:demo_die 5s
