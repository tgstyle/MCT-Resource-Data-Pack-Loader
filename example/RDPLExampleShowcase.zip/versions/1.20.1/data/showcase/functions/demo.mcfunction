schedule clear showcase:demo_die
schedule clear showcase:demo_deck
schedule clear showcase:demo_turns
schedule clear showcase:demo_tie
schedule clear showcase:demo_order
schedule clear showcase:demo_board
schedule clear showcase:demo_move
schedule clear showcase:demo_end
tellraw @a ["",{"text":"Showcase games: ","color":"gold"},{"text":"the Showcase now runs its own commands, one every four seconds, each after a line naming it. Watch the chat."}]
schedule function showcase:demo_die 5s
