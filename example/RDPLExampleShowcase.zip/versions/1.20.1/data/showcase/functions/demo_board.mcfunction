execute at @p run fill ~-1 ~ ~2 ~14 ~30 ~11 minecraft:air
execute at @p run fill ~-1 ~-1 ~2 ~14 ~-1 ~11 minecraft:stone
rdplserver game board end showcase
execute as @p at @s run rdplserver game board start showcase_checkers showcase ~3 ~ ~3
execute as @p at @s run tp @s ~ ~ ~ -45 20
tellraw @a ["",{"text":"Games 6/7 ","color":"gold"},{"text":"A board game on a cleared pad in front of you, to the south east: checkers with sheep and pigs: "},{"text":"/rdplserver game board start showcase_checkers showcase","color":"aqua"}]
schedule function showcase:demo_move 4s
