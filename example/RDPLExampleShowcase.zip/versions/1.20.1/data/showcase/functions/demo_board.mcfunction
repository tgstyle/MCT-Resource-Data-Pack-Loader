tellraw @a ["",{"text":"Games 6/7 ","color":"gold"},{"text":"A board game, 3 blocks south east: checkers with sheep and pigs: "},{"text":"/rdplserver game board start showcase_checkers showcase","color":"aqua"}]
execute as @p at @s run rdplserver game board start showcase_checkers showcase ~3 ~ ~3
schedule function showcase:demo_move 4s
