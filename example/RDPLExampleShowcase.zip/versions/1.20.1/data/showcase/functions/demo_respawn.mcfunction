tellraw @a ["",{"text":"Cards 4/4 ","color":"gold"},{"text":"A respawn card: the tour kills you once, and goes on once you respawn."}]
scoreboard players set @p scdown 1
kill @p
