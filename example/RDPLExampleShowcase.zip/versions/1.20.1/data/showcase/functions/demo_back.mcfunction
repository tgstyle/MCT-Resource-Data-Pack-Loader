scoreboard players reset @s scdown
schedule function showcase:demo_end 4s
