tellraw @a ["",{"text":"Games 7/7 ","color":"gold"},{"text":"Your first move, by square names, and the computer answers for Dark: "},{"text":"/rdplserver game board move showcase c3 d4","color":"aqua"}]
execute as @p at @s run rdplserver game board move showcase c3 d4
schedule function showcase:demo_end 4s
