tellraw @a ["",{"text":"Games 7/7 ","color":"gold"},{"text":"The computer plays your side, Light, and answers for Dark, a move every second; the tour goes on once the game is won or drawn: "},{"text":"/rdplserver game board ai showcase Light 1","color":"aqua"}]
rdplserver game board ai showcase Light 1
rdplserver game board ai showcase Dark 1
scoreboard players set #wait scdemo 1
