tellraw @a ["",{"text":"Cards 3/4 ","color":"gold"},{"text":"A biome_enter card: off to the nearest river, where the card for water biomes shows: "},{"text":"/rdplserver goto minecraft:river","color":"aqua"}]
execute as @p at @s run rdplserver goto minecraft:river
schedule function showcase:demo_respawn 10s
