execute if score #wait scdemo matches 1 run schedule function showcase:demo_command 4s
scoreboard players set #wait scdemo 0
