tellraw @a ["",{"text":"Cards 2/4 ","color":"gold"},{"text":"A y_level card: a lift 100 blocks up takes you above y 100, where the High Air card shows as you fall."}]
execute as @p at @s run tp @s ~ ~100 ~
schedule function showcase:demo_water 4s
