tellraw @a ["",{"text":"Games 1/7 ","color":"gold"},{"text":"A pack die, its faces weighted three, two and one: "},{"text":"/rdplserver game die omen","color":"aqua"}]
execute as @p at @s run rdplserver game die omen
schedule function showcase:demo_deck 4s
