schedule function showcase:demo 5s
