tellraw @a ["",{"text":"Tour over. ","color":"gold"},{"text":"Right-click one of your sheep to play on. "},{"text":"/rdplserver game board end showcase","color":"aqua"},{"text":" clears the board."}]
tellraw @a ["",{"text":"/function showcase:demo","color":"aqua"},{"text":" runs the tour again."}]
