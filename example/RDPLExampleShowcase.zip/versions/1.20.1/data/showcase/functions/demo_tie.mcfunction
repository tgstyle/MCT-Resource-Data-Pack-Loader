scoreboard objectives add scmatch dummy
scoreboard players set North scmatch 2
scoreboard players set South scmatch 2
scoreboard players set East scmatch 1
tellraw @a ["",{"text":"Games 4/7 ","color":"gold"},{"text":"A tiebreak: North and South are level at 2 on the scmatch objective, so a draw picks the winner: "},{"text":"/rdplserver game tiebreak scmatch","color":"aqua"}]
execute as @p at @s run rdplserver game tiebreak scmatch
schedule function showcase:demo_order 4s
