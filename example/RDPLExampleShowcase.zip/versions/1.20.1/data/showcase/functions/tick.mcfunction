execute as @a[tag=!rdpl_creative] run function showcase:creative
