tellraw @a ["",{"text":"Cards 1/4 ","color":"gold"},{"text":"A card shown on command, a center card over a PNG: "},{"text":"/rdplserver card showcase:command_center_image","color":"aqua"}]
execute as @p at @s run rdplserver card showcase:command_center_image
schedule function showcase:demo_high 4s
