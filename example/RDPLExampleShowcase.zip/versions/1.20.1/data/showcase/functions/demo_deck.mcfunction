tellraw @a ["",{"text":"Games 2/7 ","color":"gold"},{"text":"A card from the keepsakes deck, drawn without putting it back: "},{"text":"/rdplserver game deck draw keepsakes","color":"aqua"}]
execute as @p at @s run rdplserver game deck draw keepsakes
schedule function showcase:demo_turns 4s
