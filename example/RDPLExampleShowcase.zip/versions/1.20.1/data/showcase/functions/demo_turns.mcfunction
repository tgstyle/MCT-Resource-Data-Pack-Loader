tellraw @a ["",{"text":"Games 3/7 ","color":"gold"},{"text":"Turns: a scoring file with \"turns\" makes the sides take turns while a round runs, each turn on a clock shown on the action bar. The Showcase runs no round, so no turn clock ticks here; the Game Hall example plays a Duel turn by turn."}]
schedule function showcase:demo_tie 4s
