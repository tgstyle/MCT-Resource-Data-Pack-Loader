scoreboard players tag @s remove scend
scoreboard players reset @s sctime
kill @e[type=armor_stand,tag=scdemo]
tellraw @a ["",{"text":"Tour over. ","color":"gold"},{"text":"/rdplserver game board end showcase","color":"aqua"},{"text":" clears the board."}]
tellraw @a ["",{"text":"/function showcase:demo","color":"aqua"},{"text":" runs the tour again."}]
