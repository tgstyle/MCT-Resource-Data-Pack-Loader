scoreboard players tag @e[type=armor_stand,tag=scdemo] remove scmove
scoreboard players tag @e[type=armor_stand,tag=scdemo] add scend
summon area_effect_cloud ~ ~ ~ {Tags:["scdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Games 7/7 ","color":"gold"},{"text":"Your first move, by square names, and the computer answers for Dark: "},{"text":"/rdplserver game board move showcase c3 d4","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game board move showcase c3 d4
