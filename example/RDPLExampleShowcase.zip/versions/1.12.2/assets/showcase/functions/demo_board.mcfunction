scoreboard players tag @e[type=armor_stand,tag=scdemo] remove scboard
scoreboard players tag @e[type=armor_stand,tag=scdemo] add scmove
summon area_effect_cloud ~ ~ ~ {Tags:["scdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Games 6/7 ","color":"gold"},{"text":"A board game, 3 blocks south east: checkers with sheep and pigs: "},{"text":"/rdplserver game board start showcase_checkers showcase","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game board start showcase_checkers showcase ~3 ~ ~3
