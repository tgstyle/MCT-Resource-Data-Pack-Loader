scoreboard players tag @e[type=armor_stand,tag=scdemo] remove scboard
scoreboard players tag @e[type=armor_stand,tag=scdemo] add scmove
summon area_effect_cloud ~ ~ ~ {Tags:["scdemo"],Radius:0.0f,WaitTime:0,Duration:80}
execute @p ~ ~ ~ fill ~-1 ~ ~2 ~14 ~30 ~11 minecraft:air
execute @p ~ ~ ~ fill ~-1 ~-1 ~2 ~14 ~-1 ~11 minecraft:stone 0
execute @p ~ ~ ~ rdplserver game board end showcase
execute @p ~ ~ ~ rdplserver game board start showcase_checkers showcase ~3 ~ ~3
tp @p ~ ~ ~ -45 20
tellraw @a ["",{"text":"Games 6/7 ","color":"gold"},{"text":"A board game on a cleared pad in front of you, to the south east: checkers with sheep and pigs: "},{"text":"/rdplserver game board start showcase_checkers showcase","color":"aqua"}]
