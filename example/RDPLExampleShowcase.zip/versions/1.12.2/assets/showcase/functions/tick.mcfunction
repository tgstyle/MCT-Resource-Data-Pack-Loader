gamemode creative @a[tag=!rdpl_creative]
scoreboard players tag @a[tag=!rdpl_creative] add rdpl_creative
execute @e[type=armor_stand,tag=scstart] ~ ~ ~ function showcase:demo unless @e[type=area_effect_cloud,tag=scdemo]
execute @e[type=armor_stand,tag=scdie] ~ ~ ~ function showcase:demo_die unless @e[type=area_effect_cloud,tag=scdemo]
execute @e[type=armor_stand,tag=scdeck] ~ ~ ~ function showcase:demo_deck unless @e[type=area_effect_cloud,tag=scdemo]
execute @e[type=armor_stand,tag=scturns] ~ ~ ~ function showcase:demo_turns unless @e[type=area_effect_cloud,tag=scdemo]
execute @e[type=armor_stand,tag=sctie] ~ ~ ~ function showcase:demo_tie unless @e[type=area_effect_cloud,tag=scdemo]
execute @e[type=armor_stand,tag=scorder] ~ ~ ~ function showcase:demo_order unless @e[type=area_effect_cloud,tag=scdemo]
execute @e[type=armor_stand,tag=scboard] ~ ~ ~ function showcase:demo_board unless @e[type=area_effect_cloud,tag=scdemo]
execute @e[type=armor_stand,tag=scmove] ~ ~ ~ function showcase:demo_move unless @e[type=area_effect_cloud,tag=scdemo]
scoreboard players add @a[score_sctime_min=0] sctime 1
execute @a[tag=sccommand,score_sctime_min=80] ~ ~ ~ function showcase:demo_command
execute @a[tag=schigh,score_sctime_min=80] ~ ~ ~ function showcase:demo_high
execute @a[tag=scwater,score_sctime_min=80] ~ ~ ~ function showcase:demo_water
execute @a[tag=screspawn,score_sctime_min=200] ~ ~ ~ function showcase:demo_respawn
execute @a[tag=scend,score_sctime_min=80] ~ ~ ~ function showcase:demo_end
