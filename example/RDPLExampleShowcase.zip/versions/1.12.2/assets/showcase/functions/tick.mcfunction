gamemode creative @a[tag=!rdpl_creative]
scoreboard players tag @a[tag=!rdpl_creative] add rdpl_creative
