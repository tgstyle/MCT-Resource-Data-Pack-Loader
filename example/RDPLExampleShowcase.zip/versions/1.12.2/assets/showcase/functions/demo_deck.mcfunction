scoreboard players tag @e[type=armor_stand,tag=scdemo] remove scdeck
scoreboard players tag @e[type=armor_stand,tag=scdemo] add scturns
summon area_effect_cloud ~ ~ ~ {Tags:["scdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Games 2/7 ","color":"gold"},{"text":"A card from the keepsakes deck, drawn without putting it back: "},{"text":"/rdplserver game deck draw keepsakes","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game deck draw keepsakes
