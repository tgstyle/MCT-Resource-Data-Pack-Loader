scoreboard players tag @s remove sccommand
scoreboard players tag @s add schigh
scoreboard players set @s sctime 0
tellraw @a ["",{"text":"Cards 1/4 ","color":"gold"},{"text":"A card shown on command, a center card over a PNG: "},{"text":"/rdplserver card showcase:command_center_image","color":"aqua"}]
execute @p ~ ~ ~ rdplserver card showcase:command_center_image
