scoreboard players tag @e[type=armor_stand,tag=scdemo] remove scorder
scoreboard players tag @e[type=armor_stand,tag=scdemo] add scboard
summon area_effect_cloud ~ ~ ~ {Tags:["scdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Games 5/7 ","color":"gold"},{"text":"A work order, 3 blocks north west: a chest with a spare iron pickaxe, iron ore past it, and a Miner. Put a sign on the chest with Dig on its first line, and the Miner digs the ore into it."}]
execute @p ~ ~ ~ setblock ~-3 ~ ~-3 minecraft:chest 0 replace {Items:[{Slot:0b,id:"minecraft:iron_pickaxe",Count:1b}]}
execute @p ~ ~ ~ fill ~-6 ~ ~-6 ~-5 ~1 ~-5 minecraft:iron_ore
execute @p ~ ~ ~ summon showcase:miner ~-3 ~ ~-1 {HandItems:[{id:"minecraft:iron_pickaxe",Count:1b},{}]}
