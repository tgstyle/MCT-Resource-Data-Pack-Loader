kill @e[type=armor_stand,tag=scdemo]
kill @e[type=area_effect_cloud,tag=scdemo]
execute @p ~ ~ ~ summon armor_stand ~ 250 ~ {Tags:["scdemo","scstart"],Marker:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b}
execute @p ~ ~ ~ summon area_effect_cloud ~ 250 ~ {Tags:["scdemo"],Radius:0.0f,WaitTime:0,Duration:100}
