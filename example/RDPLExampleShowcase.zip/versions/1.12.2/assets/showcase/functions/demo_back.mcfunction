scoreboard players reset @s scdown
scoreboard players tag @s add scend
scoreboard players set @s sctime 0
