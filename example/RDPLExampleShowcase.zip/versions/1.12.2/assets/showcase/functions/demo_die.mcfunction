scoreboard players tag @e[type=armor_stand,tag=scdemo] remove scdie
scoreboard players tag @e[type=armor_stand,tag=scdemo] add scdeck
summon area_effect_cloud ~ ~ ~ {Tags:["scdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Games 1/7 ","color":"gold"},{"text":"A pack die, its faces weighted three, two and one: "},{"text":"/rdplserver game die omen","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game die omen
