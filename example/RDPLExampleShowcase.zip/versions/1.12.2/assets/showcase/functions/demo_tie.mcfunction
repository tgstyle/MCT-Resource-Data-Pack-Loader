scoreboard players tag @e[type=armor_stand,tag=scdemo] remove sctie
scoreboard players tag @e[type=armor_stand,tag=scdemo] add scorder
summon area_effect_cloud ~ ~ ~ {Tags:["scdemo"],Radius:0.0f,WaitTime:0,Duration:80}
scoreboard objectives add scmatch dummy
scoreboard players set North scmatch 2
scoreboard players set South scmatch 2
scoreboard players set East scmatch 1
tellraw @a ["",{"text":"Games 4/7 ","color":"gold"},{"text":"A tiebreak: North and South are level at 2 on the scmatch objective, so a draw picks the winner: "},{"text":"/rdplserver game tiebreak scmatch","color":"aqua"}]
execute @p ~ ~ ~ rdplserver game tiebreak scmatch
