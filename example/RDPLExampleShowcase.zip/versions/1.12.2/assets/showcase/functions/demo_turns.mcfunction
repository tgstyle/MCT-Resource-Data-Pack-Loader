scoreboard players tag @e[type=armor_stand,tag=scdemo] remove scturns
scoreboard players tag @e[type=armor_stand,tag=scdemo] add sctie
summon area_effect_cloud ~ ~ ~ {Tags:["scdemo"],Radius:0.0f,WaitTime:0,Duration:80}
tellraw @a ["",{"text":"Games 3/7 ","color":"gold"},{"text":"Turns: a scoring file with \"turns\" makes the sides take turns while a round runs, each turn on a clock shown on the action bar. The Showcase runs no round, so no turn clock ticks here; the Game Hall example plays a Duel turn by turn."}]
