scoreboard players tag @s remove scwater
scoreboard players tag @s add screspawn
scoreboard players set @s sctime 0
tellraw @a ["",{"text":"Cards 3/4 ","color":"gold"},{"text":"A biome_enter card: off to the nearest river, where the card for water biomes shows: "},{"text":"/rdplserver goto minecraft:river","color":"aqua"}]
execute @p ~ ~ ~ rdplserver goto minecraft:river
