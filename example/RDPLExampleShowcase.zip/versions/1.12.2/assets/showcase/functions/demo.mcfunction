kill @e[type=armor_stand,tag=scdemo]
kill @e[type=area_effect_cloud,tag=scdemo]
scoreboard objectives add sctime dummy
scoreboard objectives add scdown dummy
scoreboard players tag @a remove sccommand
scoreboard players tag @a remove schigh
scoreboard players tag @a remove scwater
scoreboard players tag @a remove screspawn
scoreboard players tag @a remove scend
scoreboard players reset @a sctime
scoreboard players reset @a scdown
execute @p ~ ~ ~ summon armor_stand ~ 250 ~ {Tags:["scdemo","scdie"],Marker:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b}
execute @p ~ ~ ~ summon area_effect_cloud ~ 250 ~ {Tags:["scdemo"],Radius:0.0f,WaitTime:0,Duration:100}
tellraw @a ["",{"text":"Showcase games: ","color":"gold"},{"text":"the Showcase now runs its own commands, one every four seconds, each after a line naming it, and plays a whole game of checkers before it ends. Watch the chat."}]
