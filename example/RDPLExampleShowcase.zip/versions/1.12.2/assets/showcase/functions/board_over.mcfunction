execute @e[type=armor_stand,tag=scwait] ~ ~ ~ scoreboard players tag @p add sccommand
execute @e[type=armor_stand,tag=scwait] ~ ~ ~ scoreboard players set @p sctime 0
kill @e[type=armor_stand,tag=scdemo]
kill @e[type=area_effect_cloud,tag=scdemo]
