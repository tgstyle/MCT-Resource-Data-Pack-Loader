scoreboard players tag @s remove schigh
scoreboard players tag @s add scwater
scoreboard players set @s sctime 0
tellraw @a ["",{"text":"Cards 2/4 ","color":"gold"},{"text":"A y_level card: a lift 100 blocks up takes you above y 100, where the High Air card shows as you fall."}]
execute @p ~ ~ ~ tp @p ~ ~100 ~
