# RDPL Showcase
## What to try
You are in **creative**. Each card below fires on its own trigger:
- Log in for the first time: a **center card** with its panel
- Walk into an *ocean* or a *river*: a **corner card** with no panel
- Fly above **y 100**: a corner card over a PNG, in the {runic}rune cipher{/runic}
- Play for **one minute**: a center card titled in Unicode runes
- Die and respawn: a corner card with its panel
- Run `/rdplserver card showcase:command_center_image`
## The welcome
The pack option `welcomeAsNote` shows the welcome as a note instead of a card.
