# The Keeper's Stone
## A short story in Markdown
*The wind came off the water at dusk*, and **PLAYERNAME** found the stone where the old road ends.
![The keeper's stone](showcase:textures/gui/keepers_stone.png)
Its face was cut with letters nobody had read in a hundred years:
> {runic}The one who reads this keeps the light{/runic}
The keeper had left three things behind:
1. A lantern with no oil
2. A map with the ***coast*** drawn in
3. A note that said ~~turn back~~ *go on*
---
### What the stone asks
- Watch the water
- Climb high and read the sky
  - The runes change when you are above the clouds
- Come back when you fall
The rest of the story is yours.
