RDPL Colony Example
===================

Drop the zip into rdploader/ and make a NEW world. Load this pack on its
own: with 'auto' world template selection another pack's template can be
chosen instead of this one.

The world is flat and creative, held at noon on peaceful difficulty, with
no natural spawns. Everything here is a work order from orders/colony.json:
a job the pack's workers do for the player who opens it.

Building the yard
-----------------

When you close the world intro, or at your first login when the intro is
skipped, the yard builds itself around you five seconds later and names
each site in chat: cards/yard.json, a first_join card shown once per
world, runs functions/yard_wait.mcfunction, which leaves a marker stand
and a five second cloud that the gameLoopFunction yard_tick watches.
/function colony:yard builds another yard where you stand. It builds
four work sites, each with a chest and a worker beside it:

    3 blocks south     the mine chest, holding a spare iron pickaxe, a
                       cube of eight iron ore past it, and a Miner
    north west         the chop chest and a spare axe, a pillar of four
                       logs, and a Lumberjack
    north east         the farm chest and a spare hoe, a ripe wheat
                       field around a water block, and a Farmer
    6 blocks south,    an empty haul chest, a chest of cobblestone a few
    west               blocks off, and a Porter

Opening an order
----------------

1. A sign. Place a sign on a chest and write Mine, Chop, Farm or Haul on
   its first line. The order opens at that chest, and the sign's second
   line counts down what is still wanted. Break the sign or the chest to
   cancel it.
2. A tool. Right-click a worker, not sneaking, with a pickaxe, an axe or a
   hoe. It takes the tool, hands back the one it held, and works that job
   at the nearest chest.
3. A stock chest. Rename a chest Stock in an anvil and place it near the
   cobblestone. Put one cobblestone in its first row: the Porter keeps
   that slot topped up to a full stack.

The first player to give a free worker a job owns it from then on. A free
worker can also be hired outright: right-click it with an emerald.

What each order shows
---------------------

    Mine    "job": "mine" on iron ore. "areaByTier" lets a worker with a
            better pickaxe reach farther: 8 blocks with none or a wooden
            or golden one, 12 with stone, 16 with iron, 24 with diamond
            or better. Up to two
            workers at once, at priority 2, digging half again as fast as
            a player. Besides the Miner, any member of a scoreboard team
            named Diggers, or any mob tagged digger, may take it. It
            closes once 8 are in the chest.
    Chop    "job": "gather" on logs, with "deliver": "self": the
            Lumberjack keeps the 4 logs in its own storage instead of
            walking them back, and the order counts them as they come.
    Farm    "job": "farm" on wheat with "standing": 16, so it never
            closes: the Farmer harvests ripe wheat and replants it
            whenever the chest holds fewer than 16.
    Haul    "job": "haul" on cobblestone: the Porter carries 32 out of
            the other chest into this one. The stock chest works under
            this order too, since it is the pack's first haul order.

Settings beside the orders
--------------------------

    "stockName": "Stock"      the chest name that makes a stock chest
    "hire": "minecraft:emerald"
                              the item that hires a free worker
    "spawnCap": 1             when no worker comes to an order within ten
                              seconds, one of its takers is spawned at
                              its chest, once

The workers
-----------

entities/*.json makes the four workers as villager variants that never
despawn and show their names. The Miner and the Lumberjack carry storage,
the Lumberjack's taking only logs; a worker without storage carries what
it digs in its off hand. Workers drop their tool and what they hold when
they die.
