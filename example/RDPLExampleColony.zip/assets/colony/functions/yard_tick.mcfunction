execute @e[type=armor_stand,tag=cystart] ~ ~ ~ function colony:yard_start unless @e[type=area_effect_cloud,tag=cywait]
