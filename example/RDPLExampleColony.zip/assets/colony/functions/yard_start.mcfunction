execute @p ~ ~ ~ function colony:yard
kill @e[type=armor_stand,tag=cystart]
