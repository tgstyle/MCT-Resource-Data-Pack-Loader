kill @e[type=armor_stand,tag=cystart]
kill @e[type=area_effect_cloud,tag=cywait]
summon armor_stand ~ 250 ~ {Tags:["cystart"],Marker:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b}
summon area_effect_cloud ~ 250 ~ {Tags:["cywait"],Radius:0.0f,WaitTime:0,Duration:100}
