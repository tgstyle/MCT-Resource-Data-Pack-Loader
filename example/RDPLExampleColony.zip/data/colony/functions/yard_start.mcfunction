execute as @p at @s run function colony:yard
