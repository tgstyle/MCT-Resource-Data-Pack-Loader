tellraw @a ["",{"text":"Colony: ","color":"gold"},{"text":"building the work yard around you."}]
setblock ~ ~ ~3 minecraft:chest{Items:[{Slot:0b,id:"minecraft:iron_pickaxe",count:1}]}
fill ~3 ~ ~5 ~4 ~1 ~6 minecraft:iron_ore
summon colony:miner ~-1 ~ ~3 {HandItems:[{id:"minecraft:iron_pickaxe",count:1},{}]}
tellraw @a ["",{"text":"Mine, 3 blocks south: ","color":"gold"},{"text":"a chest with a spare iron pickaxe, iron ore past it, and a Miner."}]
setblock ~-4 ~ ~-3 minecraft:chest{Items:[{Slot:0b,id:"minecraft:iron_axe",count:1}]}
fill ~-7 ~ ~-6 ~-7 ~3 ~-6 minecraft:oak_log
summon colony:lumberjack ~-4 ~ ~-1 {HandItems:[{id:"minecraft:iron_axe",count:1},{}]}
tellraw @a ["",{"text":"Chop, north west: ","color":"gold"},{"text":"a chest with a spare axe, four logs, and a Lumberjack."}]
setblock ~4 ~ ~-3 minecraft:chest{Items:[{Slot:0b,id:"minecraft:iron_hoe",count:1}]}
fill ~6 ~-1 ~-6 ~8 ~-1 ~-4 minecraft:farmland[moisture=7]
fill ~6 ~ ~-6 ~8 ~ ~-4 minecraft:wheat[age=7]
setblock ~7 ~ ~-5 minecraft:air
setblock ~7 ~-1 ~-5 minecraft:water
summon colony:farmer ~4 ~ ~-1 {HandItems:[{id:"minecraft:iron_hoe",count:1},{}]}
tellraw @a ["",{"text":"Farm, north east: ","color":"gold"},{"text":"a chest with a spare hoe, ripe wheat around a water block, and a Farmer."}]
setblock ~-4 ~ ~6 minecraft:chest
setblock ~-8 ~ ~8 minecraft:chest{Items:[{Slot:0b,id:"minecraft:cobblestone",count:64},{Slot:1b,id:"minecraft:cobblestone",count:64}]}
summon colony:porter ~-4 ~ ~4
tellraw @a ["",{"text":"Haul, south west: ","color":"gold"},{"text":"an empty chest, a chest of cobblestone a few blocks off, and a Porter."}]
tellraw @a ["",{"text":"The yard is ready, and the workers wait for your orders. ","color":"gold"},{"text":"Put a sign on a chest with Mine, Chop, Farm or Haul on its first line, or right-click a worker with a pickaxe, axe or hoe. An emerald hires a free worker. "},{"text":"/function colony:yard","color":"aqua"},{"text":" builds another yard where you stand."}]
