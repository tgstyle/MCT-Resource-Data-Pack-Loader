# RDPL Container Example

Drop the zip into `rdploader/` and make a NEW world. Load this pack on its
own: with `auto` world template selection another pack's template can be
chosen instead of this one, and then you land somewhere less convenient
than a flat creative field.

The world is a void with a 41 by 41 grass platform at the spawn, creative,
fixed at noon, with mob spawning turned off by a gamerules file, so there is
nothing to do but open the eight things this pack adds. They are all in one
creative tab, RDPL Containers.

Six of them are blocks. Place one, right-click it, and it behaves as a chest
does: it keeps what you leave in it, drops it when broken, answers a
comparator by how full it is, and takes a name in an anvil.

    Pouch             3 wide, 1 row. The smallest a container can be, and
                      proof that the screen is drawn to fit rather than
                      picked from a set of fixed sizes.

    Locker            5 wide, 4 rows. An odd width the vanilla chest screen
                      has no artwork for.

    Crate             9 wide, 3 rows, with a loot table. Exactly a vanilla
                      chest, so it uses the vanilla screen unchanged.

    Strongbox         9 wide, 6 rows, with a loot table and the chest model,
                      lid animation and chest sound included.

    Vault             12 wide, 8 rows, with a loot table. Past every vanilla
                      size, so the whole screen is assembled at draw time.

    Hoard             12 wide, 9 rows. The largest allowed. On a 1080
                      display at GUI scale `auto` it clips a few pixels top
                      and bottom; scale 3 shows it whole.

Two of them are carried. Right-click with one in hand to open it, and its
contents ride in the item, so handing it to somebody hands over what is
inside.

    Pouch (carried)   9 wide, 1 row, worn in the Curios charm slot.

    Satchel           9 wide, 3 rows, worn in the Curios back slot.

## What each part of the pack shows

    container         The block or item type is "container", and a
                      "container" object underneath it carries the rest.
                      rows and columns are the size, and both are clamped:
                      9 rows and 12 columns is the ceiling.

    lootTable         Crate, Strongbox and Vault each roll
                      minecraft:chests/simple_dungeon the first time a
                      player opens them, the way a dungeon chest fills.

    chestModel        Strongbox sets it to a texture name rather than true,
                      containertest:entity/chest/strongbox, so it draws as
                      a chest in its own color instead of the vanilla brown,
                      for the placed block and the item in hand alike. The
                      texture it names is a pixel map at
                      textures/entity/chest/strongbox.png.json that extends
                      the vanilla chest sheet and tints it, so no artwork
                      was drawn for it at all.

    curioSlot         The carried Pouch asks for "charm" and the Satchel for
                      "back". Where Curios is installed the item goes in
                      that slot and the pouch key opens it without taking it
                      off, V by default, pressed again to step to the next
                      one worn. Without Curios the slot is ignored and the
                      right-click still works. The 1.12.2 key "bauble" is
                      still read and mapped onto the nearest Curios slot.

    no blockstates    Nothing under assets but lang and textures. The
                      blockstate, the block model and the item model of each
                      block are generated from textures/block/<name>.png,
                      and each carried item's model from
                      textures/item/<name>.png. Strongbox gets the mod's own
                      pack_chest model because chestModel says so.

    lang              One line per block and per item, the game's own keys:
                      block.containertest.crate, item.containertest.satchel,
                      itemGroup.containertest.containers for the tab.

    tabs              The creative tab is a file, tabs/containers.json, and
                      blocks and items name it as containertest:containers.

    pixel maps        None of the textures in this pack are PNG files. Each
                      is a .png.json naming a palette and a row of
                      characters per line of pixels. The six block faces
                      all extend one template, crate_face, and change only
                      the palette; the two carried items are drawn as
                      themselves; and the chest sheet is the vanilla one
                      with a tint laid over it.

    worldtemplates    The void world and its platform, the creative mode,
                      the seed and the noon clock all come from
                      worldtemplates/container_example.json, the same keys
                      the config has.

    gamerules         doMobSpawning is off in all three vanilla dimensions,
                      named by id. Game rules from a pack apply to new
                      worlds, so an existing save keeps whatever it already
                      had.
