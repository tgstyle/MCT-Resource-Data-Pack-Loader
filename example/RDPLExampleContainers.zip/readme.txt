RDPL Container Example
======================

Drop the zip into rdploader/ and make a NEW world. Load this pack on its
own: with 'auto' world template selection another pack's template can be
chosen instead of this one, and then you land somewhere less convenient
than a flat creative field.

The world is flat, creative, fixed at midday, with mob spawning turned off
by a gamerules file, so there is nothing to do but open the eight things
this pack adds. They are all in one creative tab, RDPL Containers.

Six of them are blocks. Place one, right-click it, and it behaves as a chest
does: it keeps what you leave in it, drops it when broken, answers a
comparator by how full it is, and takes a name in an anvil.

    Pouch             3 wide, 1 row. The smallest a container can be, and
                      proof that the screen is drawn to fit rather than
                      picked from a set of fixed sizes.

    Locker            5 wide, 4 rows. An odd width the vanilla chest screen
                      has no artwork for.

    Crate             9 wide, 3 rows, with a loot table. Exactly a vanilla
                      chest, so it uses the vanilla screen unchanged.

    Strongbox         9 wide, 6 rows, with a loot table and the chest model.

    Vault             12 wide, 8 rows, with a loot table. Past every vanilla
                      size, so the whole screen is assembled at draw time.

    Hoard             12 wide, 9 rows. The largest allowed, matching the
                      biggest Iron Chest offers. On a 1080 display at GUI
                      scale 'auto' it clips a few pixels top and bottom;
                      scale 3 shows it whole.

Two of them are carried. Right-click with one in hand to open it, and its
contents ride in the item, so handing it to somebody hands over what is
inside.

    Pouch (carried)   9 wide, 1 row, worn in any Baubles slot.

    Satchel           9 wide, 3 rows, worn in the Baubles body slot.

What each part of the pack shows
--------------------------------

    container         The block or item type is "container", and a
                      "container" object underneath it carries the rest.
                      rows and columns are the size, and both are clamped:
                      9 rows and 12 columns is the ceiling.

    lootTable         Crate, Strongbox and Vault each roll
                      minecraft:chests/simple_dungeon the first time a
                      player opens them, the way a dungeon chest fills.
                      Placing one yourself disarms it, so it cannot be used
                      to print loot.

    chestModel        Strongbox sets it to a texture name rather than true,
                      so it draws as a chest in its own color instead of
                      the vanilla brown. The texture it names is a pixel
                      map that extends the vanilla chest sheet and tints
                      it, so no artwork was drawn for it at all. The same
                      name goes in the blockstate under "texture", or the
                      item in your hand and the block on the ground come
                      out different colors.

    bauble            The carried Pouch asks for "trinket", which fits
                      every square in the Baubles tab, and the Satchel asks
                      for "body", which fits that one square and no other.
                      Both are ignored, with everything else still working,
                      when Baubles is not installed. Press V to open what
                      you are wearing without taking it off, and press it
                      again to step to the next one.

    blockstates       Every block ships one, in the forge_marker form with
                      a "blocks" section. A pack block gets no texture at
                      all without it. Strongbox points at the mod's own
                      model, resourcedatapackloader:pack_chest, so the item
                      in your hand is chest-shaped; the rest use cube_all.

    models/item       The two carried items keep their models at
                      models/item/<file>/<variant>.json, not
                      models/item/<file>.json. An item with variants is
                      registered under that longer path and nothing is
                      drawn if it is not there.

    lang              Every block and every item needs a name line, and the
                      key carries the namespace with its colon:
                      tile.containertest:crate.crate.name for a block,
                      item.containertest:satchel.satchel.name for an item.
                      Miss one and the game shows the key instead.

    pixel maps        None of the textures in this pack are PNG files. Each
                      is a .png.json naming a palette and a row of
                      characters per line of pixels. The six block faces
                      all extend one template, crate_face, and change only
                      the palette; the two carried items are drawn as
                      themselves; and the chest sheet is the vanilla one
                      with a tint laid over it.

    gamerules         doMobSpawning is off in all three vanilla dimensions.
                      Game rules from a pack apply to new worlds, so an
                      existing save keeps whatever it already had.
