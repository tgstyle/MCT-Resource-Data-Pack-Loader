# RDPL Vein Shape Example (real terrain, prospecting)

Drop the zip into `rdploader/` and make a NEW world. An ordinary overworld
with three vein entries in its stone, one per pattern, each with its own ore
and rich / normal / poor tiers, between y -56 and y 56. Load this pack on its
own: with `auto` world template selection another pack's template can be
chosen instead of this one.

Dig, or fly through the ground in creative; a vein is up to 48 blocks across
and tall, one in about four chunks per entry. They replace stone, deepslate,
tuff, andesite, diorite and granite, so this is also the replace-target
check the void example cannot make.

    plain_vein     pattern default. Iron ore, with gold ore at the rich
                   heart and gravel at the poor fringe. A warped blob.
    banded_vein    pattern banded. Coal ore, diamond ore rich, cobblestone
                   poor. Layers stacked every few blocks.
    tube_vein      pattern tube. Lapis ore, emerald ore rich, andesite
                   poor. Hollow tubes winding up through the rock.

Indicators: every vein leaves three to six marker blocks on the surface
above it, within 4 blocks past its footprint: raw iron blocks and gravel over
an iron vein, coal blocks and cobblestone over coal, lapis blocks and andesite
over lapis, with about two spots in five left bare. Walk the surface and dig
under a cluster of them.

Prospecting: the IRON PICKAXE is the prospecting tool. Sneak and break any
block with it for a reading on every vein entry, "Possible hit on Iron
south-west of this location, deeper down", or with a COMPASS for coal only,
within 4 chunks. The reading never gives a position, only a compass direction
and up or down, and it is right about land that has not generated yet. Both
items say what they prospect for in their tooltip. The sample block is
destroyed and drops nothing (`prospectDrops` is off by default), and the
break costs the item two points of durability.

`/rdplserver vein banded_vein 8` lists where the coal veins are seeded within
8 chunks, nearest first.

WRONG if a vein ends at a chunk edge, if indicators sit over nothing, if the rich block appears outside a
vein, or if two chunks disagree about where a vein is.
