RDPL Adventure Mine
===================

Drop the zip into rdploader/ and make a NEW world. A flat stone plain, thirty
blocks deep over bedrock, started in adventure mode, where nothing can be
broken by hand and the stone cannot be broken at all. Everyone who logs in is
drawn onto the Miners and handed an iron pickaxe and eight bread. With that
pickaxe, and only on that side, the coal breaks; everything else is solid.

The coal
--------
worldgen/coal.json seeds the top seven layers of stone with coal, thick
enough that patches show on the surface everywhere. hardness/coal.json sets
"keeps": true, so a coal block is mined out, drops, wears the pickaxe and
plays the break sound, and is still there to mine again. It never runs out.
"miningTime": 2.0 makes it take twice as long as coal in a normal world.

block_drops/coal.json adds a drop on top of the coal: one break in ten also
drops an iron ingot ("chance": 0.1). Change the chance to change the pace.

Ten iron
--------
advancements/ten_iron.json is an ordinary advancement: hold ten iron ingots
at once and it is earned. hardness/coal.json names it under "becomes", so the
moment anyone earns it every coal block in the world turns into gold ore, the
loaded chunks at once and the rest as they load or are made. hardness/gold.json
is the group the gold then follows: the same side and pickaxe, "keeps" again,
and a slower "miningTime" of 3.0.

Who can break what
------------------
Both hardness groups carry an "adventure" object: who may break the group in
adventure mode, and with what in hand. Both name the Miners and the iron
pickaxe. Stone has no group, so it stays as solid as adventure mode makes it.

The sword and the anvil
-----------------------
You start with a wooden sword, a pickaxe and bread, on the Raiders side; the
sword and the pickaxe never wear out ("unbreakable" on the team's gives), and
neither does the iron sword in the chest. In
the hut is a chest holding an iron sword, and it does not swing: anvils/sword.json
locks it until the Sword Rite advancement is earned, and tells you so when you
try. Next to it stands an anvil. With three levels, put the iron sword in the
anvil's left slot and the wooden sword in the right, and the iron one comes
back with Sharpness II for those three levels; the wooden sword is spent, since
an anvil only ever works on a pair. Taking it out earns the rite
(advancements/sword_rite.json, an impossible criterion the anvil grants). From
then on it swings, and it chops the wall as the wooden one did.

A faster pickaxe
----------------
anvils/pickaxe.json is the other piece of work: the iron pickaxe in the left
slot and at least ten coal in the right, for one level, and the pickaxe comes
back with Efficiency II, the ten coal spent. Mine the coal in the floor for
it. A "result" key would hand back a different item instead, tags and all.

Where the levels come from
--------------------------
The east wall of the hut is oak planks, and hardness/planks.json opens them to
the Raiders holding a wooden sword, wood or any axe, twice as slow as planks
are, with "keeps": true so the wall never wears out. block_drops/planks.json
drops two to four experience on every other plank you chop, so the wall is
where the three levels come from. Two oak logs in the middle of that wall are
the door: hardness/logs.json opens them the same way, without "keeps", so
chop them and walk out. The coal pays experience too.

The side
--------
teams/raiders.json is one team. "picks": 64 with "picksFrom": ["players"]
draws every player who logs in onto it, and "gives" puts the sword, the
pickaxe and the bread in their inventory as they join. The side is what the
hardness groups key on: off it, nothing in this world can be broken.

The lair
--------
Twenty blocks east of the hut, past the plank wall, stands a nether brick lair
with its mouth facing the hut, a glowstone in its roof, an anvil and a chest
with an unbreakable iron axe. teams/trolls.json names a "standIn": while no
player is on the Trolls, one Herobrine is kept alive at the lair's floor,
summoned when missing; the moment a player joins the side with
/rdpl team join trolls, the stand-in steps aside. entities/herobrine.json is
that mob: a glowing zombie with a wooden axe that takes the player as a target
without seeing them, walks at them and chops what its axe can. The plank wall
and the log door let the Trolls' side and Herobrine himself through, as they
let the Raiders. The lair's "spawnBox" makes anything else spawning inside it
a Troll too.

Herobrine sets "collectsExperience": true, so he gathers experience the way a
player does. The planks he chops drop the same two to four points yours do,
and he pulls those orbs in and takes them; a player he kills drops experience
for him, and he builds levels on the player's curve. It is kept on him through
a save, and when he dies he drops it as a player would. The log names each
level he reaches. To watch it, add an objective on the level criterion:

    /scoreboard objectives add trolllevel level
    /scoreboard objectives setdisplay sidebar trolllevel

His row is his UUID. A function can act on it with
execute @e[type=adventuremine:herobrine,score_trolllevel_min=3] ...

The hut
-------
gamerules/quiet.json turns natural spawning off and runs functions/hut every
tick; the first tick a player is in the world it calls functions/build once
(an emerald block under the spawn marks it done). That lays a glass hut around
the spawn, seven wide and three high inside, with a glowstone in the roof, two
coal blocks in the floor, the chest, the anvil, and the plank wall with its
log door to the east. Nothing waits outside for now.

The lobby, the leader and the round
-----------------------------------
worldintro/lobby.json shows one still page (texts/lobby.txt) to every player
as they log in, saying all of this, and moves on by itself after thirty
seconds ("time"); the round cannot be started while anyone is still on it,
and /rdpl round start names who.

scoring/wall.json keeps one objective and sets "opens": { "by": "leader" }, so
the world starts in a lobby: nothing is scored, no clock runs, and everyone
stands in the hut picking sides with /rdpl team join. Everyone who logs in is
drawn onto the Raiders, and the first to join them leads ("lead": "first");
the side's "leadRuns" runs functions/leader as that player each time the lead
passes, which makes them glow for half a minute and tells everyone who leads;
whoever wants to be Herobrine joins the Trolls, and the AI one steps aside.
When all are in, the leader runs /rdpl round start: five seconds count down,
the Raiders are put in the hut and the Trolls in the lair ("spawn" on each
side), and the round runs five minutes, a point for a kill, five for
Herobrine. Then the standings show, the map is rebuilt (the template's
"resetRuns" runs functions/build again, "resetSendsTo" brings everyone back
to the hut), inventories and experience are cleared, the kits are handed out
again, and the lobby opens for the next round.

The round also ends the moment one side is wiped out ("lastStanding"). A
Raider who dies is out and watches as a spectator until the round is over; the
Trolls fall when Herobrine dies, since the stand-in is not replaced while the
round runs. The side left standing takes the round, and the lobby opens again.
