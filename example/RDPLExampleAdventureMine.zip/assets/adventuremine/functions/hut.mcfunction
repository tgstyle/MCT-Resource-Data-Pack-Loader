execute @p ~ ~ ~ detect 0 2 0 minecraft:stone -1 function adventuremine:build
