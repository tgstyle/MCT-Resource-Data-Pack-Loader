fill -3 31 -3 3 34 3 minecraft:glass
fill -2 31 -2 2 33 2 minecraft:air
fill 3 31 -2 3 33 2 minecraft:planks
setblock 3 31 0 minecraft:log
setblock 3 32 0 minecraft:log
setblock 0 34 0 minecraft:glowstone
setblock -2 30 -2 minecraft:coal_ore
setblock 2 30 2 minecraft:coal_ore
setblock -2 31 2 minecraft:anvil
setblock -2 31 -2 minecraft:chest 0 replace {Items:[{Slot:13b,id:"minecraft:iron_sword",Count:1b,tag:{Unbreakable:1b}}]}
fill 19 31 -4 27 36 4 minecraft:nether_brick
fill 20 31 -3 26 35 3 minecraft:air
fill 19 31 -1 19 33 1 minecraft:air
setblock 23 36 0 minecraft:glowstone
setblock 23 30 0 minecraft:obsidian
setblock 26 31 0 minecraft:anvil
setblock 26 31 -3 minecraft:chest 0 replace {Items:[{Slot:13b,id:"minecraft:iron_axe",Count:1b,tag:{Unbreakable:1b}}]}
setblock 0 2 0 minecraft:emerald_block
