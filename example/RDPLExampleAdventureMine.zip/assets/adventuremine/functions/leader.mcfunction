effect @s minecraft:glowing 30 0 true
tellraw @a ["",{"selector":"@s","color":"gold"},{"text":" leads the Raiders. When everyone is ready, they start with /rdpl round start","color":"yellow"}]
