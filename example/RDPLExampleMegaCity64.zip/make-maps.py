import json, os, glob

HERE = os.path.dirname(os.path.abspath(__file__))
NS = os.path.join(HERE, 'assets', 'megavillage')
if not os.path.isdir(NS): NS = os.path.join(HERE, 'pack', 'assets', 'megavillage')
MAPS = os.path.join(NS, 'structuremaps')
DEFS = os.path.join(NS, 'villages')
STYLES = ('blue', 'smoke', 'panel')

# (width, cell, grid, heights: {height: (weight, mostCount)}, villagers)
SIZES = [
    (16, 16, 1, {32: (4, 10), 64: (3, 8), 96: (2, 6), 128: (1, 4)}, 2),
    (32, 32, 1, {64: (3, 6), 96: (3, 6), 128: (2, 6), 160: (2, 4), 192: (1, 4), 224: (1, 4), 256: (1, 4)}, 3),
    (64, 32, 2, {64: (2, 6), 128: (2, 4), 192: (1, 4), 256: (1, 4)}, 4),
]

def layer(piece, grid):
    return {'palette': {'a': 'megavillage:' + piece}, 'map': ['a' * grid] * grid}

for old in glob.glob(os.path.join(MAPS, 'frame_*.json')) + glob.glob(os.path.join(DEFS, 'frame_*.json')):
    os.remove(old)
made = 0
for width, cell, grid, heights, villagers in SIZES:
    for height, (weight, most) in heights.items():
        layers = height // cell
        for style in STYLES:
            name = 'frame_%d_%d_%s' % (width, height, style)
            pieces = ['f%db_%s' % (cell, style)] + ['f%dm_%s' % (cell, style)] * (layers - 2) + ['f%dt_%s' % (cell, style)]
            with open(os.path.join(MAPS, name + '.json'), 'w') as out:
                json.dump({'name': 'Frame %d wide %d high %s' % (width, height, style), 'cell': cell, 'layers': [layer(p, grid) for p in pieces]}, out, indent=2)
                out.write('\n')
            with open(os.path.join(DEFS, name + '.json'), 'w') as out:
                json.dump({'type': 'template', 'structure': 'megavillage:' + name, 'weight': weight, 'leastCount': 1, 'mostCount': most,
                           'width': width, 'height': height, 'depth': width, 'villagers': villagers, 'villagerX': width // 4, 'villagerY': 1, 'villagerZ': width // 4}, out, indent=2)
                out.write('\n')
            made += 1
print('wrote %d maps and defs' % made)
