Mega Village
============

A superflat rubic world holding one deliberately enormous village, for watching
how the street generator behaves with no terrain fighting it, with a skyline
that climbs to 256 blocks over the street.

What it sets up
---------------
  rubicWorld / worldMaxHeight    a rubic world with its ceiling at 512, so a
                                 256 high tower standing on the y64 surface has
                                 room above it. A vanilla world stops at 256
                                 and would cut the tall buildings short.
  cloudHeight 0=384              lifts the clouds over the tallest roofs, which
                                 top out at 319; vanilla draws them at 128,
                                 through the middle of the skyline.
  worldType / generatorOptions   superflat, bedrock + stone + 60 dirt + grass,
                                 plains biome, villages enabled. Surface y64,
                                 above sea level, so nothing bridges or grades.
  structureAt villages=0,0       pins the village to the world origin, bypassing
                                 spacing, separation and flat-ground checks.
  structureSpacing villages=256  keeps any second village 4096 blocks away so it
                                 cannot collide with the first.
  villagePlotsLeast 1000         the size to grow to. villagePlotsMost 0 lifts
                                 the ceiling so nothing stops it early.
  worldSpawn 0,0                 you spawn in the middle of it.
  worldTime 6000                 noon, locked, so it is always lit for looking at.
  villageBlockSizes 16, 32, 64   every district rolls one of three block
                                 depths at equal odds, so the city mixes fine
                                 grids of small blocks with coarse ones.
  pregenOnNewWorld               not set. The game makes the 12 chunk spawn
                                 floor up front and the rest as you explore. A
                                 rubic column is 36 cubes tall here, so land
                                 beyond the floor is slower to make than in a
                                 plain world and a wide view distance can stall
                                 the server for tens of seconds right after
                                 the floor is done. Set it, 40 makes 81x81
                                 chunks, about 640 blocks out, to have the
                                 whole city finished before you walk into it.

Street dressing matches CityStreets so the roads read the same: concrete road,
white edge lines, light blue sidewalks, yellow dashed center, gray alleys, iron
bar lamp posts with glowstone heads, zebra crossings at junctions, and oak
street trees on the verges (villageDecor, one spot in four, from the
street_tree worldgen entry in this zip).

The buildings are structure maps rather than vanilla houses (villagePieces
blacklists all nine vanilla house and farm pieces). Forty-five maps compose
frame buildings from small NBT templates: 16x16 shops from 32 to 128 high,
32x32 towers from 64 to 256 high, and 64x64 quads from 64 to 256 high, each in
three facade styles - light blue glass, gray glass, and white concrete panels
with window bands. The taller a building, the rarer its roll, and a district
only builds what fits its block depth, so the skyline mixes itself. The frames
come from make-frames.py in the Mega City 32 example; the maps and their
village defs come from make-maps.py in this zip, which lists the heights and
weights at its top. Run it against an unpacked copy and rezip after changing
the set.

Installing
----------
Drop MegaVillage.zip in the rdploader folder and make a NEW world. The template
only applies at world creation.

What to watch
-------------
villagePlotsLeast is an ask, not a promise: the log line "grew N district(s) to
N plot(s) against the asked minimum of 1000" says what it actually reached.
Growth marches out by district hops and scales its reach with plot size, so the
full 1000 seats even at these footprints - a fresh world lands a little over
the ask, a bit under a kilometer and a half across.
