Mega City 64
============

A superflat rubic world that is one endless city: every district of the world
is a town of its own, so the streets run on wherever you go and the city has
no edge. It is for watching how the street generator behaves with no terrain
fighting it, with a skyline that climbs to 256 blocks over the street, sewers
under the streets, a subway under those, and a railway through each town.

What it sets up
---------------
  rubicWorld / worldMaxHeight    a rubic world with its ceiling at 512, so a
                                 256 high tower standing on the y64 surface has
                                 room above it. A vanilla world stops at 256
                                 and would cut the tall buildings short.
  worldMinHeight -64             the floor, 64 blocks under the vanilla one, so
                                 there is world under the flat's own ground.
  cloudHeight 0=384              lifts the clouds over the tallest roofs, which
                                 top out at 319; vanilla draws them at 128,
                                 through the middle of the skyline.
  worldType / generatorOptions   superflat: bedrock, 59 stone, 4 dirt, grass,
                                 plains biome, villages enabled. Surface y64,
                                 above sea level, so nothing bridges or grades,
                                 with 60 blocks of ground under it, which is
                                 what the sewers at 8 and the subway at 24 are
                                 bored through, in stone rather than dirt.
  villageCitySpacing 1           the continuous city: every district is a town,
                                 a plaza with the well at its center and the
                                 streets of its well's cross run out to the
                                 district's edges, where they meet the next
                                 district's as straight avenues. The city keeps
                                 generating wherever you go. villagePlotsMost 0
                                 sets no ceiling on the plots a district seats.
  worldSpawn 0,0                 you spawn in the city, like anywhere else.
  worldTime 6000                 noon, locked, so it is always lit for looking at.
  villageBlockSizes 16, 32, 64   every district rolls one of three block
                                 depths at equal odds, so the city mixes fine
                                 grids of small blocks with coarse ones.
  pregenOnNewWorld               not set. The game makes the 12 chunk spawn
                                 floor up front and the rest as you explore. A
                                 rubic column is 36 cubes tall here, so land
                                 beyond the floor is slower to make than in a
                                 plain world and a wide view distance can stall
                                 the server for tens of seconds right after
                                 the floor is done. Set it, 40 makes 81x81
                                 chunks, about 640 blocks out, to have the
                                 whole city finished before you walk into it.

Streets
-------
Roads are nine wide: black concrete with a white edge line down each side, a
yellow center line dashed two on and one off, and two blocks of light gray
sidewalk outside the lines. Alleys are gray, zebra crossings are painted at
junctions, and a dead end closes with a barrier or a sidewalk. Lamp posts
stand on the curb as a structure rather than a stack of blocks
(villagePathLampStructure, street_lamp.nbt in this zip): a five high iron bar
pole, a sea lantern head with an end rod reaching out on each of its four
sides, and an iron cap. A lamp is placed centered on its spot and never
turned, which is why it is the same from every side. make-lamp.py in the Mega
City 32 example writes the file.

Under the streets
-----------------
Every street carries a sewer eight blocks under it (villageSewer*): stone
brick lined, five wide, a water channel down the middle with a chiseled walk
either side, glowstone in the roof every eight blocks, mossy cobblestone
worked into the lining and vines on the walls, and a manhole with a ladder and
a wooden trapdoor where two streets cross.

Every district is a town of its own and carries its own lines. Two subway
lines run under it at depth 24 (villageSubway*): a stone
brick bore in a mix of plain, cracked, mossy and chiseled, two tracks of
vanilla rail on gravel and spruce sleepers, a powered rail every sixteen, and
glowstone in the roof. A station sits where each line passes nearest the
plaza and another every 120 blocks where the ground allows, built from
subway_station.nbt, its stair head opening onto the street.
Every line climbs to the surface at one end, beyond the last street over
it, and runs on as an open railway (villageSubwaySurfaces 100).

One railway crosses each town on the surface (villageRail*), laid before the
first street so the blocks grow around it: two tracks of vanilla rail on
gravel and spruce sleepers with a gray shoulder each side and a powered rail
every sixteen. Streets cross it straight through.
Oak street trees stand on the verges (villageDecor, one spot in four, from the
street_tree worldgen entry in this zip).

Buildings
---------
The buildings are structure maps rather than vanilla houses (villagePieces
blacklists all nine vanilla house and farm pieces). Forty-five maps compose
frame buildings from small NBT templates: 16x16 shops from 32 to 128 high,
32x32 towers from 64 to 256 high, and 64x64 quads from 64 to 256 high, each in
three facade styles - light blue glass, gray glass, and white concrete panels
with window bands. The taller a building, the rarer its roll, and a district
only builds what fits its block depth, so the skyline mixes itself. The maps
and their village defs come from make-maps.py in this zip, which lists the
heights and weights at its top. Run it against an unpacked copy and rezip
after changing the set.

Installing
----------
Drop RDPLExampleMegaCity64.zip in the rdploader folder and make a NEW world.
The template only applies at world creation.

What to watch
-------------
With worldgenDebug on, rdpl.log names every district as it is made: "The
district at X, Z runs the four streets of its well's cross to its edges,
laying N new length(s) of avenue, so they meet the next districts' at the
seams". The X and Z of those lines step by one district size, the same grid
in every direction. Every chunk of the city is built up, so new ground costs
what the middle of a big city costs: fly slowly or pregenerate the ground you
start on.
