# RDPL Mega City 64

A superflat world tiled edge to edge with city districts, for watching the
street generator with no terrain fighting it: concrete streets, sewers under
them, two subway lines under those, a railway across the city, street trees,
and frame buildings from 27 up to 251 blocks tall on plots 16, 32 and 64 wide. Drop the zip into `rdploader/` and make a
NEW world; load it on its own so its template is the one taken.

What it sets up
---------------
    worldType flat, generatorOptions   bedrock, 123 stone, 4 dirt, grass:
                                       the surface is y64 with 128 blocks of
                                       stone under it for the sewers (depth 8)
                                       and the subways (depth 24) to bore
    worldMinHeight -64, worldMaxHeight 512
                                       the tallest towers top out at y 314, so
                                       the world is raised well clear of them
    cloudHeight minecraft:overworld=384
                                       clouds drawn above the skyline instead
                                       of through it
    structureAt city=0,0               pins the city's center district to the
                                       world origin
    villagePlotsLeast 1000             the size to grow to: districts are added
                                       ring by ring around the center until the
                                       city holds a thousand plots, each district
                                       a plaza with the well at its center and
                                       four streets out of it that join the next
                                       district's, alleys off them, the railway
                                       and subways running straight through
    villagePlotsMost 0                 lifts the ceiling so nothing stops it early
    villageCitySpacing 32              keeps any second city 32 districts away
    villagePlotsBackRow true           a second plot behind every one that
                                       fronts a street
    villageBlockSizes 16=1, 32=1, 64=1 the three plot widths at equal odds
    villageDecor street_tree=2, empty=6
                                       an oak on one verge spot in four
    worldSpawn 73,91                   on the street just off the center district's plaza
    worldTime 6000                     noon, so it is always lit

Streets
-------
Nine wide: black concrete with a white edge line down each side, a yellow
center line dashed two on and one off, and two blocks of light gray sidewalk
outside the lines. Alleys are gray, zebra crossings are painted at junctions,
and a dead end closes into a cul-de-sac. Lamp posts stand on the
curb as a structure (street_lamp.nbt): a five high iron bar pole, a sea lantern
head with an end rod out of each side, and an iron cap.

Under the streets
-----------------
Every street carries a sewer eight blocks under it: stone brick lined, five
wide, a water channel down the middle with a chiseled walk either side,
glowstone in the roof every eight blocks, mossy cobblestone worked into the
lining and vines on the walls, a manhole with a ladder and a wooden trapdoor
where two streets cross, and a loop of sewer around the plaza well with a
manhole down onto it (villageSewerWellEntrance).

Two subway lines run north to south under the city at depth 24, the first
under the center district's street and the second under the next street east
(villageSubwaySpacing 96, rounded up to whole districts): a stone
brick bore, two tracks of rail on gravel and spruce sleepers, a powered rail
every sixteen, glowstone in the roof. A station stands where each line passes
nearest the plaza and every 120 blocks where a street runs over it, built from
subway_station.nbt with subway_entrance.nbt marking the way in. The lines
stay underground (villageSubwaySurfaces 0) and run on 48 blocks past the
city's edge.

One railway crosses the city east to west on the surface, along the back edge
of the center district's blocks, laid before
the streets so they cross it straight through and the plots keep off it: two
tracks on gravel and spruce sleepers with a gray shoulder each side and a
powered rail every sixteen, running 64 blocks past the city's edge.

Buildings
---------
Forty-five frame buildings in fifteen sizes, each in three facades (light blue
glass, gray glass, and white concrete panels with window bands): 16 wide at 27,
59, 91 and 123 high, 32 wide at 59 up to 251 high in 32-block steps, and 64
wide quads at 59, 123, 187 and 251 high. Weights fall with height, so the tall
ones are rare but not capped. On 1.12.2 they were composed from the f16 and
f32 frame pieces by structure maps; here each is one baked template in
structures/, stacked from the same pieces. Each block rolls its plots by
weight and seats the largest first wherever they fit, then fills the gaps and
seats a second row behind the front one, so the skyline mixes itself. The plaza holds a spire or a
fountain, two to one.

What to watch
-------------
"Generated world preset ... on flat" and "The overworld is flat" on load, "The
city around district 0, 0 grows N district(s) to N plot(s) against the asked
minimum of 1000" as the first chunk near it is made, then per district "The
district at X, Z seats N plot(s) along its streets and alleys, N of them behind a
plot that fronts one, by size {16x16=N, 32x32=N, 64x64=N}",
"The well ... stands at", "The sewer loop around the well", and the station
lines. WRONG if a street stops short of a district edge with nothing beyond
it, if a building stands on open track, or if a sewer is cut by a subway bore
without being walled.

Street trees are an oak entry in worldgen/ (street_tree.json, never sown on its
own) that the streets plant on their verges.

Differences from the 1.12.2 pack: one enormous village of a thousand plots is
a district grid here, the world is a flat overworld with a raised ceiling rather
than a cubic-chunks world, the subway bore is plain stone brick (no weighted mix on
this line), and villagePieces is gone, there being no vanilla houses to block.
