say RDPL functions work. Run with /function rdpltest:hello
give @p rdpltest:materials 1 5
