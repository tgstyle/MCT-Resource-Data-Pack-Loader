say RDPL fluid function reaction fired
