say RDPL functions work. Run with /function rdpltest:hello
give @p rdpltest:test_gem 1
