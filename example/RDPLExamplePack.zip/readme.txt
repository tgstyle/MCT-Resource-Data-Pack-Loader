RDPL Example Pack
=================

A working content pack for MCT Resource Data Pack Loader that uses every kind
of file the loader understands. It ships no textures of its own, every model
points at a vanilla texture, so it cannot fail for a missing png.

Drop the zip into rdploader/ and start the game. Use it as a reference when
writing your own pack: each folder below is a complete, working example.


WHAT IS IN HERE
---------------

    blocks/           four blocks, covering variants, render layers, custom
                      collision, flammability and ore drops
    items/            plain items, a food and a drinkable
    fluids/           a coloured fluid with a bucket and a world block
    worldgen/         an ore vein
    furnace/          smelting recipes added and removed
    fuels/            burn times by item and by ore dictionary name
    oredict/          ore dictionary names added to items other mods own
    recipes/          crafting recipes added
    recipe_removals/  crafting recipes deleted in bulk
    overrides/        properties of things vanilla owns changed in place:
                      block hardness, light and sound, item stack sizes,
                      food put on things that never were food, and a
                      potion's effects rewritten
    sounds/           a sound event
    advancements/     an advancement
    loot_tables/      a vanilla block drop replaced
    loot_injections/  a pool added to a vanilla table, leaving it otherwise
                      intact
    functions/        an mcfunction
    registry_remap/   a rename map, documented but inert
    tabs/             the creative tab icon

    assets/minecraft/recipes/chest.json
                      a single recipe deleted by putting a removal marker at
                      the same path the recipe lives at


WHAT TO CHECK IN GAME
---------------------

WORLDGEN            Testium Ore generates between y=20 and y=90 in stone. The
                    definition sets "retrogen": true, so chunks that already
                    existed before the pack was added get the veins too, a few
                    chunks per tick as you walk into them. Each chunk is done
                    once and remembers it in its own save data, so it will not
                    double up. Leave retrogen out and you only get veins in
                    brand new chunks. Veins are deliberately large and frequent.
                    Mining one drops redstone ore, sometimes glowstone too,
                    and more with Fortune. It also drops 1 to 4 xp.

RENDER LAYERS       Test Glass is see through and does not darken what is
                    under it. Lit Test Glass is the yellow stained texture and
                    gives off full light. Both are variants of one block, so
                    this also covers block metadata.

COLLISION SHAPE     Test Low Box is half height, both to stand on and to look
                    at. The shape comes from two separate things and a pack
                    needs both: "bounds" in the block definition sets
                    collision, and the model in models/block/half_block.json
                    sets what you see. Setting only bounds gives you a full
                    cube you can walk into. This is a plain block with a small
                    model, not a slab. For a real slab see below.

SLAB                Testium Slab and Mossy Testium Slab. Place one, then place
                    a second on top of it, and the two merge into a full
                    block. Break the full block and it drops two slabs. One
                    definition file produces two registry entries, the slab
                    and its double, and the double never appears in creative.
                    A slab holds at most 8 variants, not 16, because one bit
                    of metadata is spent on top or bottom.

STAIRS              Testium Stairs place facing you, flip when you aim at the
                    upper half of a block, and form corner shapes against
                    other stairs. A stairs block holds exactly one variant,
                    because facing, half and shape use all of its metadata.
                    That is why vanilla has a separate stairs block per wood
                    type, and why "modelBlock" exists: the stairs take their
                    material and render layer from another block.

TOOL                Testium Pickaxe, harvest level 3, 900 uses. It should mine
                    obsidian. Repair it with a Testium Gem in an anvil.

ARMOUR              Testium Chestplate. The material sets "armorTexture" to
                    minecraft:iron, so it renders with the vanilla iron armour
                    texture and the pack ships no armour png. Point that at
                    your own namespace once you have textures at
                    textures/models/armor/<name>_layer_1.png and _layer_2.png.

FENCE               Testium Oak Fence and Testium Birch Fence. They connect to
                    each other and to solid blocks. A fence keeps all 16
                    variants, because its connections are worked out when the
                    block is drawn rather than stored, so none of the
                    metadata is spent on them.

PANE                Testium Pane connects like glass panes do. Same story as
                    the fence for metadata.

                    Both of these need a blockstate that covers the
                    connection properties, not just the variant. Look at
                    blockstates/test_fence.json to see the shape: a submodel
                    per side, added when that side is true.

DOOR, TRAPDOOR      Testium Door, Testium Trapdoor and Testium Fence Gate.
AND GATE            Place the gate in a line of Testium Oak Fence and it
                    joins up; place it against a Testium Wall and it drops
                    down into the wall. Put two doors side by side and they
                    swing as a pair, one hinged left and one hinged right.

                    All three spend their whole metadata on their shape, so
                    each holds exactly one variant and each is keyed in the
                    lang file by its own name twice. Their blockstates are
                    keyed by the shape alone, with no blocks property:
                    32 entries for the door, 16 each for the other two.
                    powered is dropped from the door and the gate, as the
                    game drops it from its own, so write the keys without it.

                    The models point at the vanilla parents that accept
                    textures, not at the finished vanilla models. A door
                    takes bottom and top, and both of its top models reach
                    for bottom to face their upper edge, so all four files
                    declare both. A trapdoor and a gate take one texture
                    each. Gate variants set uvlock, as the game's own do.

                    Their items differ. A door in the hand is a flat sprite
                    over textures/items/door_wood.png, while the trapdoor
                    and gate items parent a block model, the bottom flap and
                    the closed gate.

OVERRIDES           Seven files under overrides/minecraft/ change vanilla
                    things in place. The file path names the target, so
                    overrides/minecraft/stone.json changes minecraft:stone.

                    Stone mines almost instantly by hand, glows at light
                    level 10 and sounds like glass. Obsidian mines in about
                    a second with any shovel, or by hand. Cobblestone
                    catches fire from a neighboring flame and is slippery,
                    slightly worse than ice. Ender pearls stack to 64
                    instead of 16.

                    Planks are one file doing a block key and an item key
                    at once: the block breaks about as fast as dirt, and
                    the item can be eaten. Hold it, aim at the sky, and
                    hold right click for 2 drumsticks and Speed II; aiming
                    at a block places it instead, which is vanilla's use
                    order. The apple is an existing food edited in place,
                    restoring 5 drumsticks. Both are alwaysEdible, so they
                    work on a full hunger bar, but eat them in SURVIVAL,
                    because creative hides the hunger bar. The Potion of
                    Swiftness now grants Levitation for 10 seconds instead
                    of Speed; drinking works in creative.

                    These are live. Rename the pack zip to end in
                    .disabled, run /rdpl reload, and every value snaps back
                    to vanilla without a restart. Rename it back, reload
                    again, and they return.

LOOT INJECTION      Break gravel. About one time in four it also drops a
                    Testium Gem. loot_injections/gravel_bonus.json adds a pool
                    to the vanilla gravel table instead of replacing the whole
                    table, so the normal gravel and flint drops still happen.
                    Compare with loot_tables/, which replaces a table
                    outright, as the dirt example does.

MATERIAL            materials/testium.json defines one material that feeds
                    both the tool and the armour. Durability, harvest level,
                    efficiency, damage, enchantability, armour reduction,
                    toughness and repair item all live there.

FLAMMABILITY        Test Planks catch from a neighbouring fire and burn away.

FOOD                Test Snack heals 2 hunger and grants Regeneration II. The
                    tooltip shows the effect in green.
                    You must be in SURVIVAL. No food can be eaten in creative
                    mode, vanilla food included, because creative disables
                    damage and eating is gated on that.

DRINK               Swift Draught grants Speed II for 30 seconds, plays the
                    drink animation and leaves a glass bottle. Unlike food it
                    works in creative, because drinking is not gated on hunger.

FLUID               Test Fluid is purple and animated. It uses the vanilla
                    water textures tinted by the colour in the definition, so
                    a pack does not have to ship fluid textures. A bucket of
                    it exists in the RDPL Test tab.

FUEL                Test Fuel burns for 4 minutes. A vanilla EMERALD burns for
                    13 minutes 20 seconds, because oredict/extra.json adds the
                    name gemTestium to the vanilla emerald and fuels/ gives
                    that name a burn time. That pair is the point of the
                    emerald: it shows a pack adding an ore dictionary name to
                    an item it does not own, then using it.

ORE DICTIONARY      A vanilla iron ingot is also ingotTestium. Check in JEI.

CRAFTING            Nine Test Fuel make a Testium Gem, and one Testium Gem
                    unmakes into nine Test Fuel.

RECIPES REMOVED     Torches cannot be crafted, removed by output.
                    Ladders cannot be crafted, removed by recipe name.
                    Chests cannot be crafted, removed by the same path marker.

FURNACE             Testium Ore smelts into a Testium Gem. Cobblestone smelts
                    into Test Fuel, because the file first removes the stone
                    recipe: an addition for an input something already smelts
                    is ignored. Sand no longer smelts into glass.

LOOT TABLE          Breaking a dirt block drops a Testium Gem instead of dirt.

SOUND               /playsound rdpltest:test_ping player @p
                    The sound is an alias for a vanilla one, so no ogg file is
                    needed to prove the event registered.

FUNCTION            /function rdpltest:hello

ADVANCEMENT         Picking up a Testium Gem grants the Testium advancement.

CREATIVE TAB        Everything is in a tab named RDPL Test, created by the
                    pack. No installed mod declares that tab. Its icon is set
                    by tabs/rdpltest.json. Without that file the tab still
                    works, but the icon is whichever block happened to claim
                    the label first, which is not something you want to leave
                    to chance.


NOTES FOR PACK AUTHORS
----------------------

The file path is the identity. assets/rdpltest/blocks/test_ore.json becomes
the block rdpltest:test_ore. There is no name field to get wrong.

Metadata is fixed forever once a world exists. Testium Gem sits at metadata 5
while Test Fuel is at 0, and the gap between them is deliberate: item
metadata may be sparse and nothing is registered in the holes. Never renumber
an existing variant.

A block holds at most 16 variants because block metadata is four bits. Unused
slots are filled automatically with hidden placeholders named open00 to
open15, which never appear in the creative menu.

Anything that needs a tile entity, a GUI, an inventory or per tick logic
still needs a real mod. This system describes what a thing is, not what it
does over time.
