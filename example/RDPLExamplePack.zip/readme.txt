RDPL Example Pack
=================

The 1.12.2 example pack, carried to this version by the forward port and
finished by hand. It uses nearly every kind of file the loader understands:
blocks, items, a fluid, materials, a creative tab, biomes, a world template,
a dimension with a gate, worldgen, a potion and its brewing, a villager
profession and trades, recipes, loot, overrides of vanilla things, a sound,
an advancement and a function. It is the example pack to start from, and
what a 1.12.2 pack becomes.

Drop the zip into rdploader/ and start the game. Make a NEW world to see the
template, the biomes and the Verdant.

WHAT IS IN HERE
---------------

    data/rdpltest/
      blocks/           35 block files: ores, glass with a lit variant, a
                        half height box, slabs, stairs, fences, a pane, a
                        wall, a door, a trapdoor and a gate, logs, leaves and
                        saplings, crops, a cane, a cactus, flowers, vines, a
                        torch, a ladder and the Verdant portal
      items/            plain items, a food, a drink, a tool, armor, a key, a
                        seed and a flask
      fluids/           a colored fluid with a bucket and a world block
      materials/        the testium material behind the pickaxe and the
                        chestplate
      tabs/             the RDPL Test creative tab and its icon
      biomes/           nine biomes for the Verdant Overworld template
      worldtemplates/   Verdant Overworld, the template a new world takes
      dimensions/       the Verdant
      gates/            the portal to the Verdant, unlocked by a Verdant Key
      worldgen/         ore shapes, flowers, cane, cactus, vines, a tree and
                        saplings
      potions/          Sure Footing, an effect
      potion_types/     the Sure Footing potion
      brewing/          awkward potion plus a Testium Gem makes it
      villagers/        the Testium Trader profession
      trades/           its trade, and one added to the vanilla farmer
      furnace/          smelting added and removed
      fuels/            burn times by item and by tag
      recipe/ (recipes/ on 1.20.1)
                        crafting recipes added
      recipe_removals/  crafting recipes deleted by output and by name
      overrides/        properties of vanilla things changed in place
      sounds/           a sound event
      advancement/ (advancements/ on 1.20.1)
                        an advancement
      loot_injections/  a pool added to the vanilla gravel table
      function/ (functions/ on 1.20.1)
                        an mcfunction
      registry_remap/   a rename map
    data/minecraft/     the dirt loot table replaced, the chest recipe and the
                        torch and ladder recipe advancements removed
    data/c/ (data/forge/ on 1.20.1)
                        the item tags the 1.12.2 ore dictionary names became
    assets/rdpltest/    lang, textures and the sound list

WHAT TO CHECK IN GAME
---------------------

WORLDGEN            Test Ore (rdpltest:cluster) generates between y 20 and
                    y 90 in stone. "retrogen": true gives chunks that existed
                    before the pack was added their veins too, once each.

OVERRIDES           Seven files under overrides/minecraft/ change vanilla
                    things in place; the file path names the target.

                    Stone breaks almost instantly, glows at light level 10
                    and sounds like glass. Obsidian breaks quickly with a
                    shovel. Cobblestone catches fire from a neighboring flame
                    and is slippery. Ender pearls stack to 64.

                    Oak planks break quickly and can be eaten: hold them,
                    aim at the sky and hold use for Speed II. The apple
                    restores 5 drumsticks. Both are alwaysEdible, so they
                    work on a full hunger bar, but eat them in survival. The
                    Potion of Swiftness grants Levitation for 10 seconds
                    instead of Speed.

                    These are live: disable the pack, run /rdpl reload, and
                    every value snaps back to vanilla without a restart.

LOOT INJECTION      Break gravel. About one time in four it also drops a
                    Testium Gem, on top of the normal gravel and flint drops.
                    data/minecraft/ replaces the dirt table outright instead,
                    so dirt drops a Testium Gem.

FOOD AND DRINK      Test Snack restores 2 drumsticks and grants Regeneration
                    II. Swift Draught grants Speed II for 30 seconds and
                    leaves a glass bottle.

TOOL AND ARMOR      Testium Pickaxe, 900 uses, mines obsidian, repaired with a
                    Testium Gem. The Testium Chestplate wears the vanilla iron
                    armor texture ("armorTexture": "minecraft:iron").

FUEL                Test Fuel burns for 4 minutes. A vanilla emerald burns for
                    13 minutes 20 seconds: the ore dictionary file put it in
                    the gems/testium tag, which is what the 1.12.2 name
                    gemTestium became, and fuels/ gives that name a burn
                    time. The Testium Gem sits in the same tag and burns as
                    long.

TAGS                A vanilla iron ingot is in the ingots/testium tag too.

CRAFTING            Nine Test Fuel make a Testium Gem, and one Testium Gem
                    unmakes into nine Test Fuel.

RECIPES REMOVED     Torches, ladders and chests cannot be crafted.

FURNACE             Test Ore smelts into a Testium Gem. Cobblestone smelts
                    into Test Fuel, because the file first removes the stone
                    recipe: an addition for an input something already smelts
                    is ignored. Sand no longer smelts into glass.

BREWING             An awkward potion and a Testium Gem brew the Potion of
                    Sure Footing: faster and harder to knock back. The effect
                    ships no icon, so it shows the RDPL fallback icon.

THE VERDANT         Four gold ingots make a Verdant Key, and eight obsidian
                    around a key make four Verdant Portal blocks. Place one and
                    step into it: the gate takes a Verdant Key from you the
                    first time and the Verdant stays open to you after that.
                    You arrive on a platform of Test Stone under a purple
                    sky, at fixed night with no clouds, in one biome; a
                    portal block there brings you back to the overworld.

SOUND               /playsound rdpltest:test_ping player @p

FUNCTION            /function rdpltest:hello says hello and gives you a
                    Testium Gem.

ADVANCEMENT         Picking up a Testium Gem grants the Testium advancement.

CREATIVE TAB        Everything is in a tab named RDPL Test, created by the
                    pack, with the Testium Gem as its icon (tabs/rdpltest.json).

WHAT CHANGED FROM 1.12.2
------------------------

The port moved every definition from assets/ to data/, rewrote ids through the
game's own data fixers (minecraft:planks is minecraft:oak_planks, a block's
metadata variants are registered under their own names), turned the ore
dictionary into item tags and the blockstates into generated ones. By hand:

    the template lost blockWorldGenerators, generatorWhitelist and
    blockGeneratorDimensions, which have nothing to control here, and the
    dungeons and lavalakes switches, which are features now rather than
    structures; dimension 7 is rdpltest:verdant, and blockOreDimensions keeps
    the overworld alone, since ore blocking is scoped through biome tags only
    the three vanilla dimensions have

    the villager has no careers or texture keys now: the profession names a
    job site block (rdpltest:test_core) and ships its look as
    textures/entity/villager/profession/testium_trader.png if it wants one

    the potion's icon key is gone, since an effect's icon is a texture at
    textures/mob_effect/sure_footing.png

    the gravel loot injection targets minecraft:blocks/gravel

    the function gives rdpltest:test_gem instead of materials with metadata 5

    the registry remap names the block registry as minecraft:block and points
    at rdpltest:cluster; the old name never existed, so it still changes
    nothing until you edit it

    on 1.21.1 the four soil blocks lost plantTypes, which NeoForge 1.21.1 does
    not have; the cane, cactus, flower and saplings name their soils already

Anything that needs a block entity, a GUI or per tick logic still needs a real
mod. This system describes what a thing is, not what it does over time.
