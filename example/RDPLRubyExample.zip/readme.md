# RDPL Ruby Example

A working content pack for MCT Resource Data Pack Loader that uses every kind
of file this version of the loader reads. Everything in it is named for ruby,
so one pack shows the whole surface: the blocks and items, the things it
changes about vanilla, the world it generates, the dimension under that world,
and the screens the player sees on the way in.

Drop the zip into `rdploader/` and start the game. Read it as a reference when
you write your own pack. Every folder below is a complete, working example, and
nothing in here needs another mod.

## It ships no images

There is not one PNG in this pack. Every texture is a pixel map, a JSON file
next to where the image would be, named `<image>.png.json`. Two kinds are in
here:

    textures/block/crate_planks.json    drawn: a palette and one character per
                                        pixel, sixteen rows of sixteen
    textures/block/ruby_crate.png.json  the same drawing with one palette entry
                                        changed, so a second texture costs four
                                        lines
    textures/item/ruby.png.json         a tint over a texture the game already
                                        has: every pixel's brightness is mapped
                                        onto the ramp from `from` to `to`

A file whose name ends `.png.json` is served as that image. A file that ends
just `.json`, like `crate_planks.json`, is a template other maps build on and
is never served. `extends` names the file, so a map that builds on a served
image keeps the `.png`: `rdplruby:textures/block/ruby_planks.png` is the ruby
plank image, `rdplruby:textures/block/crate_planks` the template beside it.
`/rdplserver pixelmap rdplruby:block/ruby_crate` prints what a map resolved
to, its palette and where each entry came from.

## What is in here

    blocks/           every block type but the portal, which a dimension brings
                      with it: ore, plain, glass with a render layer, a half
                      height box, a crate you open with an item, slab, stairs,
                      fence, gate, wall, pane, door, trapdoor, ladder, torch,
                      log, leaves, sapling, crop, flower, cane, vine, falling
                      sand, banner
    items/            plain items, a food, a drink, a potion, a potion bottle,
                      four tools, four armor pieces, a seed, and one item held
                      back by a pack option
    materials/        the one material both the tools and the armor read
    fluids/           a fluid with a bucket and a world block
    tabs/             the creative tab and its icon
    fuels/            burn times by item and by tag
    sounds/           a sound event
    potions/          two effects, one with an attribute modifier
    potion_types/     a brewable potion made of those effects
    brewing/          the brewing stand recipe that makes it
    villagers/        a profession with a job site block
    trades/           what that profession sells, per level
    entities/         two entity variants built on a vanilla mob
    exposures/        standing near ruby makes a player ill
    hardness/         one block, many mining speeds, chosen by position
    overrides/        vanilla things changed in place: hardness, light, sound,
                      stack size, flammability, food, and a potion's effects
    recipe/           crafting recipes added
    recipe_removals/  crafting recipes deleted by name and by output
    furnace/          smelting recipes added and removed
    loot_injections/  a pool added to a vanilla table, leaving the rest alone
    loot_table/       a vanilla block's drops replaced outright, and a table
                      for the player and for one entity
    player_loot/      what a player drops on death
    advancement/      an advancement
    function/         an mcfunction
    registry_remap/   a rename map, so an old world keeps its blocks
    worldgen/         sixteen entries, one per shape and one per spread
    biomes/           eight biomes: five that take a climate band each, and
                      three that take over the water and the shore
    caveregions/      a cave biome in a depth band, with cover on floor and
                      ceiling and two templates seated on its cave floors
    structure/        three small templates the imprint and the map place
    structuremaps/    a building laid out as a grid of those templates
    dimensions/       the Ruby Deep, its sky, its rules and its portal
    gates/            what a player must hold before that portal will take them
    portalframes/     the shape of frame that lights
    gamerules/        game rules that hold only in one dimension
    worldintro/       the pages shown once, the first time a player joins
    worldtemplates/   the world this pack makes, and every control group
    config/options.json
                      the two switches the pack offers in the Pack Options
                      screen

    data/minecraft/recipe/chest.json
                      a single recipe deleted by putting a removal marker at
                      the path the recipe lives at

## What to check in game

**Creative, and one seed.** The template sets `worldGameMode` to creative and
`worldSeed` to 1234, so the create screen comes up ready and everyone who
tries this pack gets the same world, which is what the distances below are
measured in. Drop both keys from `worldtemplates/ruby_world.json` for an
ordinary survival world of your own. They only apply as a world is made; a
world you already have keeps the mode it was made with.

**The world.** The pack ships a world template, and the loader's
`worldTemplate` config is `auto`, which takes the template from the highest
priority pack, so a new world is a Ruby World unless another pack outranks
this one or you name a different template. It reaches down to y -256 on Ruby Stone instead of stopping at
-64, and `noiseCaves` is `deep`, so the game's caves, tunnels and noodle
passages carry on down through all of it rather than leaving solid rock. The
bedrock is one flat layer. Set `worldTemplate` to empty in the config for a
normal world.

**The intro.** The first join scrolls two pages and then hands the world over.
It plays once per player; `/rdplserver intro` shows it again.

**Land made ahead of you.** The template pregenerates twelve chunks either way
from the spawn before anybody moves. You watch it as a spectator with the
progress on the action bar, the sky held still, and the view fogged; when it
finishes the fog clears and the pack's logo fades out.

**Every biome is the pack's.** The template turns `blockBiomes` on with only
`rdplruby` whitelisted, so no vanilla biome is placed in the overworld at all.
Five ruby biomes take a climate band each: Ruby Tundra in the icy band, Ruby
Flats in the cool, Ruby Grove in the medium, Ruby Savanna in the warm and Ruby
Dunes in the desert. Everywhere else a vanilla biome would have gone becomes
the template's `fallback`, Ruby Flats. The water and the shore come from
`roles`: every biome in the `is_ocean`, `is_river` and `is_beach` tags is
re-pointed to Ruby Ocean, Ruby River and Ruby Shore, and those three also name
the plain ocean, river and beach in their own `replaces` list, which is the
other way to say the same thing. Every one of them lays ruby grass, ruby soil,
ruby sand and Ruby Stone, so the whole overworld is the pack's, top to bottom.

**No vanilla ore.** `blockOres` is on with only `rdplruby` whitelisted, so
coal, iron and the rest are not placed and the iron and copper veins are off.
What is left underground is what this pack's own worldgen entries put there.

**Structures.** Mineshafts, strongholds, temples, monuments and mansions are
turned off in the template's `structures` block, so `/locate` cannot find
them. Villages are left on, because Ruby Grove and Ruby Flats both ask for
them and Ruby Grove asks for the spruce kind.

**The Ruby Grove.** A forest with red grass and red foliage, Ruby Cows in it,
Ruby Blooms on the ground and ruby trees. `/locate biome rdplruby:ruby_grove`. Climb on a Ruby Cow with an empty hand and it walks where you steer:
its `steerable` is true.

**The Ruby Caves.** A cave region between y -56 and 30 with Ruby Stone on a
quarter of the floor and Glowing Ruby Block on a tenth of the ceiling, Ruby
Sappers in it, and a pillar or a shrine seated on its cave floors here and
there. A sapper's helmet and pickaxe are dyed by its `tint`, because its
`tintParts` name `armor` and `held` rather than the `body` the Ruby Cow dyes:
one color, three places it can go.

**Ore and the shapes.** The `worldgen/` files are named a to p so they read in
order, one per shape: cluster veins of Ruby Ore, a large vein of Deepslate
Ruby Ore, plates, a geode with a glowing core, a belt, a flat field at y -58,
spires and hanging vents in caves, nodules, a basin under water, blooms on the
surface, ruby trees, vines under leaves, an imprint of the Ruby Shrine, a
weighted list that lands four Ruby Stone to one Ruby Block, and one entry that
waits for a pack option.

**The Ruby Shrine and the Ruby Court.** The shrine is placed by an imprint
entry that records where it stood: `/rdpl locate Ruby Shrine` answers with the
nearest one and how far it is. The court is a structure map, three by three
cells of eight with pillars on the corners, so `/locate structure
rdplruby:ruby_court` finds it like any structure.

**The Ruby Deep.** Build the frame in `portalframes/ruby_ring.json` out of
Ruby Block and light it with flint and steel. It will not take you until you are holding a Ruby, which is what
`gates/ruby_gate.json` says; without one you get told so on the action bar.
Inside, the sky is fixed at evening, gravity is lighter, fire does not spread,
your inventory survives death, and the clouds are pink. Dig out of the bottom
of the overworld and you fall into the Deep at the same x and z; fly up out of
the Deep and you come back out of the overworld's floor. Die down there and
you wake in the overworld: the Deep's `respawn` is false, so it allows no
respawn and sends you to its `respawnDimension`, a bed in the Deep ignored.
Its `groundLevel` of -240 is where an arrival lands when the heightmap finds
nothing under it. Its `terrain.structures` is false, so nothing is founded
down there, not even the villages the Ruby Grove carries above.

**Threat.** Carry rubies and the world notices. Past eight the mobs see you
further off; past twenty four they say so.

**Blocks.** Ruby Glass is see through; the lit one glows. The Ruby Low Box is
half height both to stand on and to look at, which takes two things: `bounds`
in the definition sets the collision, and `models/block/ruby_low_box.json` sets
what you see. The Ruby Crate opens with a Ruby in hand, spends it, and drops
two to four Rubies with a one in four chance of an Emerald beside them; with
anything else in hand it says what it wants, because `opensWith` sends the
block's own `.locked` line to the action bar and the pack writes that line in
`lang/en_us.json`. Broken rather than opened it just drops itself. Two Ruby Slabs merge into a full block. The stairs turn and corner.
The fence, gate and wall join up. Two doors side by side hinge as a pair.

**Ruby Stone is not one hardness.** `hardness/ruby_stone.json` spreads four
steps of hardness over the world with a noise field. The deepest red blocks
mine six times slower than the palest and take four times the blast to break.
You can see which one you are about to hit, because the pack ships a
blockstate with one model per step: the loader picks the model for a position
out of the same field it picks the hardness from, so the shade is the tell.
Give the group a height band, as this one does; outside its band every block
sits at the group's hardest step.

**Ruby fever.** Stand near Ruby Ore or Ruby Block in survival and you catch
Ruby Fever; stay in it and the second level hurts you and turns the screen. A
fire resistance potion makes you immune.

**Overrides.** Stone mines almost instantly, glows at light 10 and sounds like
glass. Obsidian gives way to a shovel. Cobblestone catches fire and is
slippery. Ender pearls stack to 64. Apples heal five drumsticks. A stick is
food, and eating one grants Speed II. The Potion of Swiftness grants
Levitation. All of it is live: rename the zip to end in `.disabled`, run
`/rdpl reload`, and every value goes back to vanilla without a restart.

**Loot.** Gravel drops a Ruby about one time in four, on top of its normal
drops, because the injection adds a pool rather than replacing the table.
Dirt drops a Ruby Shard instead of dirt, because that table is replaced
outright. Dying leaves a Ruby Shard behind.

**Recipes.** Nine Ruby Dust make a Ruby and a Ruby makes nine back. Nine
Rubies make a Block of Ruby. Ladders and torches cannot be crafted, one
removed by name and one by output. Chests cannot be crafted, removed by the
marker at their own path. Ruby Ore smelts into a Ruby, cobblestone smelts into
Ruby Dust, and sand no longer smelts into glass.

**Fuel.** Ruby Dust burns for four minutes. Anything tagged as a ruby gem
burns for eighty seconds, which is the tag the Ruby carries.

**Trading.** A villager who takes the Ruby Block as a job site becomes a
Gemcutter and sells rubies, then blocks of them.

**Pack options.** Open Pack Options from the world list or the create screen.
Cut Ruby is not registered until you turn `cut_gems` on, and the Glowing Ruby
Block veins do not exist until you turn `late_veins` on. Both need a restart,
which the screen tells you. `late_veins` is a retrogen entry, so once it is on
the veins appear in chunks that already existed, a few chunks a tick as you
walk into them.

**Sound, function, advancement.** `/playsound rdplruby:ruby_chime player @p`,
`/function rdplruby:hello`, and picking up a Ruby grants the Ruby advancement.

## Notes for pack authors

The file path is the identity. `data/rdplruby/blocks/ore.json` defines the
blocks named in its `variants`, and the namespace is the folder under `data/`.
There is no name field to get wrong.

A pack in `rdploader/` is a zip. Loose files are read only under the root's own
`assets/<namespace>` and `data/<namespace>`; a folder beside them is not a pack
and is skipped with a warning.

There is no block metadata any more. Every variant is its own registry entry,
`rdplruby:ruby_glass` and `rdplruby:lit_ruby_glass`, and you may add and remove
variants freely. Nothing has to be renumbered and nothing is reserved.

What the pack does not ship, the loader writes: blockstates, models, item
models, loot tables, the mining and tool tags, tree features, job sites, spawn
rules, damage types, the world preset with its dimension types and noise
settings. Ship a file yourself and yours wins. That is how
`models/block/ruby_low_box.json` in here beats the full cube the loader would
otherwise have written, and how the three drinkables get their fluid:
`models/item/ruby_elixir.json` draws `ruby_potion_fill` under the bottle,
two layers where the loader writes one.

`modelBlock` does two jobs. It is the block a `stairs` takes its base state
from, and it is what a block falls back to for its model when the pack ships
no texture of its own, which is how a plain block can look right with no art
at all. The fallback is the named block's own model, so give a shape block
(slab, stairs, fence, wall, pane, trapdoor, gate) a texture of its own:
without one it draws as whatever `modelBlock` names, which is a full cube.

Anything that needs a block entity, a screen, an inventory or per tick logic
still needs a real mod. This system describes what a thing is, not what it does
over time.
