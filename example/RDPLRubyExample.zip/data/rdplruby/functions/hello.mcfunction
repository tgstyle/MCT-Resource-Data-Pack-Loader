say hello from the RDPL Ruby Example pack
