RDPL Deep World Example
=======================

Drop the zip into rdploader/ and make a NEW world. Load this pack on its own:
with 'auto' world template selection another pack's template can be chosen
instead of this one, and then none of the below happens.

The overworld runs from y -320 instead of -64. Vanilla still generates its
usual -64 to 320, unchanged; this pack fills the 256 blocks below it. How tall
a dimension is gets written into the save the first time it loads, so this has
to be a new world.

Bring a creative flight, and dig or fly down through the deepslate.

    worldMinHeight    -320, a multiple of 16, which is what sets the floor.
                      Bedrock and the lava lakes move down to it.

    deepStone         the deep is andesite, and it fades out of deepslate
                      across the eight layers under -64 rather than starting
                      at a flat line, the way deepslate fades out of stone.
                      Look at y -64 from the side.

    noiseCaves        set to 'world', so the game's own caves carry on all
                      the way down: wide cheese caverns, long spaghetti
                      tunnels, noodles and the pillars in the big rooms.
                      Still water sits at its own level in aquifer pockets,
                      and the lava lakes fill the lowest ten layers. Leave
                      it out and the deep stays solid andesite for worldgen
                      entries to carve.

CAVE REGIONS
------------

Three bands, so descending passes through three different undergrounds. Each
one is a rolled cell rather than a layer, so plain caves sit between them.

    lush              y -144 to -24. Mossy cobblestone floors, brown and red
                      mushrooms scattered on them, vines hanging from the
                      ceilings. Reports itself as minecraft:jungle, so F3
                      says Jungle underground. Its spawn list is witches and
                      nothing else, and keepDefaultSpawns is off, so a witch
                      down here came from the region.

    dripstone         y -244 to -144. Terracotta on floors and ceilings, with
                      terracotta spires growing up from one and hanging from
                      the other. Reports itself as minecraft:badlands. One
                      vanilla fossil is placed at the heart of every cell.

    flooded           y -320 to -244. Reports itself as minecraft:deep_ocean.
                      On 1.12.2 its waterLevel pinned the water inside it;
                      aquifers belong to the game's noise settings now and
                      cannot be pinned per region, so it floods only where
                      the aquifers do.

The decoration is ordinary worldgen entries with caveRegions and snap set, not
a special shape: snap moves each attempt to the nearest cave floor or ceiling
first, and caveRegions refuses the attempt outside the named region. Every one
of them lists minecraft:air in replace, because what a placed shape writes
over is checked against replace and the default is stone.

Diamond ore is scattered from y -320 to -80, thickest around -200
(worldgen/deep_diamond.json, a centered spread).

WHAT TO CHECK IF IT LOOKS WRONG
-------------------------------

    bedrock at y -64
                      the template was not chosen, or the world already
                      existed.

    andesite starting abruptly
                      expected at the very bottom of the fade, not at the
                      top. The blend covers eight layers, so it is a fade,
                      not a seam.

    no regions at all
                      caveRegionPlainWeight is 1 here against a default of
                      4, so about three cells in four take a region. Fly
                      further before concluding: a cell is 128 blocks across
                      and 64 tall.

WHAT CHANGED FROM 1.12.2
------------------------

The 1.12.2 pack made a rubic world with sky islands above the vanilla one,
ravines through the deep and two banded ore veins. None of that exists on this
version: the world is one tall dimension now, so rubicWorld, the sky keys,
deepRavines and oreVeins are gone from the template, and the vein arc is
written per ore instead (see the ore veins in the HOWTO). The cave region heights moved
64 blocks down with the vanilla floor.

Anything that is not deep generation. Blocks, items, biomes, dimensions,
recipes and worldgen shapes are in RDPLExamplePack.zip, and the worldgen
shapes on their own, hanging in a void, are in RDPLExampleOrePackVoid.zip.
