RDPL Deep World Example (rubic)
===============================

Drop the zip into rdploader/ and make a NEW world. Load this pack on its own:
with 'auto' world template selection another pack's template can be chosen
instead of this one, and then none of the below happens.

The overworld is a rubic world running from y -256 to y 384. Vanilla still
generates its usual 0 to 255, unchanged; this pack fills the 256 blocks below
it and the 128 above it. Whether a dimension is rubic is written into the save
the first time it loads and cannot be changed later, so this has to be a new
world.

Bring a creative flight. Dig or fly down through the floor for the deep, and
fly up past 255 for the sky.

    deepStone         the deep is andesite, minecraft:stone@5, and it fades
                      into the window's ordinary stone across the lowest
                      eight layers of the vanilla world rather than starting
                      at a flat line. Look at y 0 from the side.

    noiseCaves        set to 'world', so the caves are the modern kind
                      everywhere, not only in the deep: wide cheese caverns,
                      long spaghetti tunnels, pillars in the big rooms and
                      funnels that open near the surface. Vanilla's own cave
                      carver is replaced, so the world above 0 looks
                      different too.

    deepRavines       long steep canyons through the deep. They take the
                      deep world's own fluids where they cut through them,
                      so one crossing a water pocket keeps its water rather
                      than draining it.

    oreVeins          two banded veins, mostly filler with the ore scattered
                      through them. Iron in diorite from y -200 to -60, gold
                      in granite from y -256 to -200. These are regions of
                      rock, not blobs: you walk into one rather than finding
                      it. Heights count from the bottom of the vanilla
                      window, which is why they are negative.

    aquifers          not a key, it comes with noiseCaves. Still water sits
                      at its own level in pockets, with walls of deep stone
                      wherever two levels meet or water meets lava, and bulk
                      lava fills the lowest layers.

    skyStone          the mirror of deepStone. The room above the vanilla
                      window is shaped by the same noise that carves the
                      deep, so what is cave down there is island up here,
                      made of end stone under its surface. skyHeights holds
                      it to y 256 through 384, and islands stop eight blocks
                      short of the ceiling so trees have room, which puts
                      the highest island block at 374.

                      The land carries the column's own surface, so an
                      overworld island reads as grass over dirt over end
                      stone, and it is decorated per cube rather than down
                      the column: trees, grass and flowers land on the
                      island instead of being scattered to the ground far
                      below. Animals settle on it as the land is made.

    skyIslands
    skyThickness      0.5 and 2.0, which are the defaults, written out here so
                      they are easy to find. At 0.5 roughly seven cubes in eight
                      of the band are empty and the islands that remain are
                      still solid enough to stand on. Lower skyIslands gathers
                      far more land: by 0.2 the band has closed into a ceiling
                      with hills standing on it rather than an archipelago,
                      measured at 81 percent solid through its middle, which is
                      almost never what you want.

CAVE REGIONS
------------

Three bands, so descending passes through three different undergrounds. Each
one is a rolled cell rather than a layer, so plain caves sit between them.

    lush              y -80 to 40. Mossy cobblestone floors, brown and red
                      mushrooms scattered on them, vines hanging from the
                      ceilings. Reports itself as minecraft:jungle, so F3
                      says Jungle underground and the water and foliage take
                      jungle colors. Its spawn list is witches and nothing
                      else, and keepDefaultSpawns is off, so a witch down
                      here came from the region.

    dripstone         y -180 to -80. Hardened clay on floors and ceilings,
                      with clay spires growing up from one and hanging from
                      the other. Reports itself as minecraft:mesa. One
                      vanilla fossil is placed at the heart of every cell.

    flooded           y -256 to -180. waterLevel pins every aquifer sample
                      point inside the region, so its caves flood to y -200
                      whatever the noise would have done. Reports itself as
                      minecraft:deep_ocean. The walls where it meets the dry
                      caves next door are shaped by the same pressure noise
                      modern versions use, not cut flat.

The decoration is ordinary worldgen entries with caveRegions and snap set, not
a special shape: snap moves each attempt to the nearest cave floor or ceiling
first, and caveRegions refuses the attempt outside the named region. Note that
every one of them lists minecraft:air in replace, because what a placed shape
writes over is checked against replace and the default is stone.

WHAT TO CHECK IF IT LOOKS WRONG
-------------------------------

    a flat floor at y 0
                      the world is not rubic. Either the template was not
                      chosen, or the world already existed.

    andesite starting abruptly
                      expected at the very bottom of the fade, not at the
                      top. The blend covers eight layers, so it is a fade,
                      not a seam.

    no regions at all
                      caveRegionPlainWeight is 1 here against a default of
                      4, so about three cells in four take a region. Fly
                      further before concluding: a cell is 128 blocks across
                      and 64 tall.

WHAT THIS PACK CANNOT SHOW
--------------------------

Per dimension keys. deepStone, noiseCaves, deepRavines and oreVeins each take
either one value or a list where an entry written dimension=value applies to
that dimension alone. This pack sets one value for each, which reaches every
rubic dimension except the End.

Anything that is not deep generation. Blocks, items, biomes, dimensions,
recipes and every worldgen shape are in RDPLExamplePack.zip, and the worldgen
shapes on their own, hanging in a void, are in RDPLExampleOrePackVoid.zip.
