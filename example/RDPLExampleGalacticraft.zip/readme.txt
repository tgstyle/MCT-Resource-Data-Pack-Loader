RDPL Galacticraft Example (1.12.2)
==================================

Drop the zip into rdploader/. Needs Galacticraft. The Frost planet
also needs GalaxySpace (with AsmodeusCore), and reads its extraplanets keys
only when ExtraPlanets is installed too. Without Galacticraft the pack's
planets are not registered at all, and the log says so.

GalaxySpace and ExtraPlanets together crash at startup until ExtraPlanets is
set up for GalaxySpace, which has nothing to do with this pack: in
config/ExtraPlanets.cfg turn "Enable Galaxy Space Compatibility" on and the
"Venus SpaceStation" and "Mars SpaceStation" off, since GalaxySpace adds
those two stations itself.

With GalaxySpace installed, AsmodeusCore's map works a planet's rocket tier
out from distance and asks the top tier for anything around another star.
To use the tiers this pack sets, turn enableNewTierSystem off in
config/AsmodeusCore/core.conf.

Launch a rocket and look past the Sol system on its destination map for
Ember.

    celestial/ember.json   a star system of its own, Ember, placed on the
                           galaxy map with its own star. Files under
                           celestial/ only draw on the map; they make no
                           dimension.

    celestial/ash.json     a planet on the map with no dimension behind it,
                           so it can be seen and selected but never landed
                           on.

    dimensions/cinder.json a nether-type planet circling Ember, reached with
                           a tier 2 rocket, never a portal. Everything that
                           is not Galacticraft's own sits in the dimension
                           itself and works without it: the dark red sky and
                           fog (they darken at night like vanilla), the big
                           hazy sun, a small planet hanging in the sky, dense
                           stars, low gravity, softer falls, a 30 minute day
                           and a weather cycle. The galacticraft block holds
                           only what Galacticraft reads: the map icon (the
                           pack's own texture), size, orbit and ring color,
                           the tier, landing by balloons, the checklist, a
                           corrosive CO2 and nitrogen atmosphere that is hot
                           and thin, meteors, fuel use, solar power, dungeons
                           and a rain of smoke instead of water.

    dimensions/frost.json  an ice planet around GalaxySpace's Tau Ceti,
                           needing a tier 5 rocket. "requires" skips the
                           whole file when GalaxySpace is missing. Its
                           galaxyspace block sets pressure, radiation, the
                           planet class, an eccentric orbit, GalaxySpace's
                           cold-reactive liquids (methane and
                           helium-hydrogen placed in the open vanish in
                           strong cold; water never freezes),
                           day and night temperature swings, solar wind and
                           a frozen storm; its extraplanets block sets
                           pressure, day and night temperatures and the
                           lander.

    exposures/frost_radiation.json
                           Frost's radiation, an RDPL exposure rather than
                           a Galacticraft addon's: any survival player on
                           Frost (dimension 72) carries the Frost Radiation
                           effect with weakness and hunger, and takes a
                           heart of damage every 10 seconds, armor or not.
                           Leaving Frost lets it wear off.

    potions/frost_radiation.json
                           the Frost Radiation effect that marks an exposed
                           player.

    textures/gui/celestialbodies/cinder.png
                           the map icon for Cinder, a 16x16 texture.

    lang/en_us.lang        the names on the map, the effect name and the
                           death message. Galacticraft looks up
                           solarsystem.<name>, star.<name> and planet.<name>.

Dimension ids 71 and 72 must be free. Change them if another mod holds
them; the log names the holder.

Every key is in the HOWTO under Galacticraft bodies, and the radiation's
under Exposures.
