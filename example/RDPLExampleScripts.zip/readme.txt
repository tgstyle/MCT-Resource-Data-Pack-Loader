RDPL Script Forms Example
=========================

A small shrine pack that uses every script form RDPL has: event entries
with inline scripts and script files, every event kind and filter key,
two scripted items, a card and the rdpl members.

Before you start
----------------

Scripts are off by default. Open config/resourcedatapackloader-common.toml,
find the [scripts] category and set

    [scripts]
        runScripts = true

then drop the zip into rdploader/ and start a NEW world (or run
/rdplserver reload). The pack adds no blocks and no mobs; everything runs
on vanilla ones. Use /give @s shrine:shrine_wand and
/give @s shrine:shrine_charm to get the two items. Switch to survival to be
hurt or to need gold.

What to check in game
---------------------

1. Join. The action bar says "Shrine pack: visit 1, not blessed"
   (player_login, scriptFile login.js; it also adds a scoreboard objective
   called shrine, so a chat line saying it exists on later joins is normal).
2. Place a log in the overworld. It is refused with "Bless yourself at the
   altar first" (block_place, a # block form, an inline script that returns
   "cancel").
3. Place a gold block. A purple sheep appears on top, the vanilla igloo top is placed 3 blocks east
   (world.placeStructure), a sound plays, a
   center card says altar number 1, and 5 seconds later the action bar says
   "The altar glows" (block_place with dimension and block filters, scriptFile
   altar_placed.js: summon, runCommand, card, schedule, data(), data(player),
   teamData, addStage). The Nether or the End does nothing: the dimension
   filter.
4. Hit the purple sheep while holding a stick. No damage, and the stick is
   on cooldown (entity_hurt with entity and item filters, cooldown, "cancel").
   Hit it with anything else and it takes damage.
5. Hold 3 gold ingots and right-click the Shrine Wand. You are blessed, get an
   emerald, and the shrine score rises (item scriptFile wand.js: world.scan,
   score, setScore, addStage, give). Without the ingots it says so, and the
   "cancel" result skips the wand's 2 second cooldown. Check with
   /scoreboard players list and /tag @s list.
6. Place a log again. It now works, because hasStage sees the blessing.
7. Right-click the Shrine Charm. It answers with hasAdvancement: it needs the
   Stone Age advancement, and without it "cancel" skips its cooldown (an item
   with an inline script).
8. Put gold ingots in a chest, place it and break it. The action bar names
   how many it held and whether it has an item handler (block_break,
   scriptFile chest_broken.js: world.scanAt, world.capability).
9. Break the gold block. The blessing and the builder tag are removed
   (block_break, inline script, removeStage). Do step 6 again to see logs
   refused.
10. Try /summon minecraft:creeper in the overworld: nothing appears
    (entity_spawn with an entity filter and a list of dimensions, "cancel").
11. Let a mob despawn far from you. world data despawns counts them once the
    world time is a multiple of 20 (entity_despawn with every). The count is
    kept in the world save, and no command shows it; it is there for a
    script to read.
12. Put some items in a furnace, then place a coal block directly on top of
    it. The coal block is used up, the furnace gets 16 coal in its fuel slot,
    burns and finishes its current smelt almost at once, and the action bar
    says "The furnace roars: N smelting, M done" (block_place with a block
    filter, scriptFile stoke_furnace.js). The script reads the furnace
    through world.capability, taking the input and output counts from its
    item handler, and changes it only through runCommand: execute if block
    to check the block below, item replace for the fuel and data merge for
    the burn and cook times. Handlers hand out reads and changes of stacks,
    but the commands are the way to write what a handler does not offer,
    such as the burn time. A coal block on anything but a furnace does
    nothing.

What each file does
-------------------

    data/shrine/scripts/events/*.json
                            one entry each: event, optional filter, every,
                            and script or scriptFile
    data/shrine/scripts/*.js
                            the script files the entries and items name
    data/shrine/items/*.json
                            the wand (scriptFile) and the charm (script)
    data/shrine/cards/altar.json
                            a card with the command trigger, raised by
                            rdpl.card("shrine:altar", "count=N")
    assets/shrine           names and models for the two items
