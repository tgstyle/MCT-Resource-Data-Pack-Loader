rdpl.runCommand("scoreboard objectives add shrine dummy");
var seen = rdpl.data(rdpl.player);
var visits = (seen.has("visits") ? seen.get("visits") : 0) + 1;
seen.set("visits", visits);
rdpl.actionbar("Shrine pack: visit " + visits + (rdpl.hasStage("shrine_blessed") ? ", blessed" : ", not blessed"));
