var x = pos.getX();
var y = pos.getY() - 1;
var z = pos.getZ();
var at = x + " " + y + " " + z;
if (rdpl.runCommand("execute if block " + at + " minecraft:furnace")) {
  var items = rdpl.world.capability(x, y, z, "items");
  var smelting = items !== null ? items.getStackInSlot(0).getCount() : 0;
  var done = items !== null ? items.getStackInSlot(2).getCount() : 0;
  rdpl.runCommand("item replace block " + at + " container.1 with minecraft:coal 16");
  rdpl.runCommand("data merge block " + at + " {BurnTime:1600,CookTime:190,CookTimeTotal:200}");
  rdpl.runCommand("setblock " + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " minecraft:air");
  rdpl.actionbar("The furnace roars: " + smelting + " smelting, " + done + " done");
}
