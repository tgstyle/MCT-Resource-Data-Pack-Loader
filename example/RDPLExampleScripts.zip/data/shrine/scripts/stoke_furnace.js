var x = pos.getX();
var y = pos.getY() - 1;
var z = pos.getZ();
var at = x + " " + y + " " + z;
if (rdpl.runCommand("execute if block " + at + " minecraft:furnace")) {
  var items = rdpl.world.capability(x, y, z, "items");
  var smelting = items !== null ? items.getAmountAsInt(0) : 0;
  var done = items !== null ? items.getAmountAsInt(2) : 0;
  rdpl.runCommand("item replace block " + at + " container.1 with minecraft:coal 16");
  rdpl.runCommand("data merge block " + at + " {lit_time_remaining:1600,lit_total_time:1600,cooking_time_spent:190,cooking_total_time:200}");
  rdpl.runCommand("setblock " + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " minecraft:air");
  rdpl.actionbar("The furnace roars: " + smelting + " smelting, " + done + " done");
}
