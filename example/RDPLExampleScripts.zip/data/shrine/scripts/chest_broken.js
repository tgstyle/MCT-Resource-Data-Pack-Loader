var x = pos.getX();
var y = pos.getY();
var z = pos.getZ();
var gold = rdpl.world.scanAt(x, y, z, "minecraft:gold_ingot");
var handler = rdpl.world.capability(x, y, z, "items");
rdpl.actionbar("Chest held " + gold + " gold ingots, item handler: " + (handler !== null));
