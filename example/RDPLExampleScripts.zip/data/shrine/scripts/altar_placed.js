if (rdpl.player) {
  var store = rdpl.data();
  var altars = (store.has("altars") ? store.get("altars") : 0) + 1;
  store.set("altars", altars);
  rdpl.data(rdpl.player).set("last_altar", pos.getX() + "," + pos.getY() + "," + pos.getZ());
  rdpl.teamData("shrine").set("founded", true);
  rdpl.addStage("shrine_builder");
  rdpl.world.summon("minecraft:sheep", pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5, "{Color:11b}");
  rdpl.world.placeStructure("minecraft:igloo/top", pos.getX() + 3, pos.getY(), pos.getZ());
  rdpl.runCommand("playsound minecraft:entity.player.levelup master @s");
  rdpl.card("shrine:altar", "count=" + altars);
  rdpl.schedule(100, function () { rdpl.actionbar("The altar glows"); });
}
