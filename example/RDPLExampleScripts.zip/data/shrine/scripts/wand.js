var gold = rdpl.world.scan(rdpl.player, "minecraft:gold_ingot");
if (gold >= 3) {
  rdpl.setScore("shrine", rdpl.score("shrine") + 1);
  rdpl.addStage("shrine_blessed");
  rdpl.give("minecraft:emerald", 1);
  rdpl.actionbar("Blessed, shrine score " + rdpl.score("shrine"));
} else {
  rdpl.actionbar("Carry 3 gold ingots, you have " + gold);
  "cancel";
}
