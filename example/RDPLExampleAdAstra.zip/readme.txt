RDPL Ad Astra Example (1.20.1 and 1.21.1)
=========================================

Drop the folder or a zip of it into rdploader/. Needs Ad Astra. Without Ad
Astra the pack's planets, stations and rocket are not registered at all, and
the log says so. The radiation exposure needs no Ad Astra, but only matters
on Frost.

Launch a rocket and look past the Solar System on its destination map for
Ember. Cinder takes a tier 2 rocket, Frost a tier 3 one. The Ember Rocket
this pack adds reaches both.

    data/rdplplanets/celestial/ember.json
                           a star system of its own, Ember, with its own
                           star. Files under celestial/ only draw on the
                           map; they make no dimension.

    data/rdplplanets/celestial/ash.json
                           a planet on the map with no dimension behind it,
                           so it can be seen but never landed on.

    data/rdplplanets/celestial/clinker.json
                           a moon circling Ash, on the map only.

    data/rdplplanets/celestial/slag.json
                           an asteroid belt around Ember, drawn as a ring
                           on the map with no dimension behind it.

    data/rdplplanets/dimensions/cinder.json
                           a nether-type planet circling Ember, reached with
                           a tier 2 rocket, never a portal. Everything that
                           is not Ad Astra's own sits in the dimension
                           itself and works without it: the dark red sky and
                           fog (they darken at night like vanilla), the big
                           hazy sun, a small planet hanging in the sky, dense
                           stars, low gravity, softer falls, a 30 minute day
                           and a weather cycle with a rain of smoke instead
                           of water. The adastra block holds only what Ad
                           Astra reads: the map icon (the pack's own
                           texture), size, orbit and ring color, the tier,
                           the landing and exit heights, fuel use, solar
                           power and a hot, corrosive atmosphere you cannot
                           breathe.

    data/rdplplanets/dimensions/cinder_station.json
                           a space station over Cinder. Build it with the
                           "+" button on Cinder's page of the planet screen
                           a rocket opens at the top of its flight, using
                           the recipe in the file: iron ingots, planks and
                           glass. Its world is always an
                           empty orbit.

    data/rdplplanets/dimensions/frost.json
                           an ice planet around Ember, needing a tier 3
                           rocket, with its own gravity, a 40 minute day and
                           a cold atmosphere. Its orbit is made for it, so
                           it can be launched from and flown back to.

    data/rdplplanets/exposures/frost_radiation.json
                           Frost's radiation, an RDPL exposure rather than
                           an Ad Astra feature: any survival player on Frost
                           carries the Frost Radiation effect with weakness
                           and hunger, and takes a heart of damage every 10
                           seconds, armor or not. Leaving Frost lets it wear
                           off.

    data/rdplplanets/potions/frost_radiation.json
                           the Frost Radiation effect that marks an exposed
                           player.

    data/rdplplanets/entities/ember_rocket.json
                           the rocket itself: a variant of Ad Astra's tier 2
                           rocket with a tier 3 reach, a 6000 unit fuel tank
                           and sixteen torches already aboard.

    data/rdplplanets/items/ember_rocket.json
                           the Ember Rocket item that places it. Get it with
                           /give @s rdplplanets:ember_rocket.

    assets/rdplplanets/textures/gui/celestialbodies/cinder.png
                           the map icon for Cinder, a 16x16 texture.

    assets/rdplplanets/lang/en_us.json
                           the names of the star system, the planets, the
                           station, the rocket, the effect and the death
                           message. Ad Astra looks up solar_system.<ns>.<name>,
                           planet.<ns>.<name> and dimension.<ns>.<name>.

Every key is in the HOWTO under Dimensions, and the radiation's under
Exposures.
