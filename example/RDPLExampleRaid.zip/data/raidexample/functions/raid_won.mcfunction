title @s title {"text":"Victory","color":"gold"}
title @s subtitle {"text":"The village held"}
effect give @s raidexample:hero_of_the_village 120 0
give @s minecraft:emerald 8
