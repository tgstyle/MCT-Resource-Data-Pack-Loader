RDPL Raid Example
=================

Drop the zip into rdploader/ and make a NEW world. Load this pack on its
own: with 'auto' world template selection another pack's template can be
chosen instead of this one.

The world is flat and creative, held at noon on normal difficulty, with a
village at spawn and no natural spawns. Everything the pack adds is in the
RDPL Raid Example creative tab.

Starting a raid
---------------

1. Join the world. The first time a player joins they are given Bad Omen
   for five minutes, and they spawn inside the village.
2. The game only counts a village once its villagers have found their
   doors, which takes a few moments. Then the Bad Omen is taken away, a
   horn sounds and the Raid bar comes up.
3. For another raid, drink an Ominous Brew inside the village. A Raid
   Captain drops one.
4. Switch to survival (/gamemode survival) if you want to be fought. A
   creative player is never attacked, so staying creative lets you watch.

The bar fills for fifteen seconds and the first wave arrives from outside
the village. Five waves come, fifteen seconds apart once the one before is
gone. Kill every raider to win: a title, eight emeralds and Hero of the
Village for two minutes. If every villager dies, the village has fallen.

What each part of the pack shows
--------------------------------

    raids/village_raid.json
                      The raid itself: the omen that starts it, the bar's
                      name and color, the delay between waves, the horn,
                      the bell and the two ending functions. Each wave is
                      a list of groups, and a group names any entity with
                      a count, fixed or a min and max. Vanilla illagers,
                      a witch and the pack's own variants mix freely.

    potions/bad_omen.json
                      The omen is a potion effect of the pack's own, with
                      its own icon drawn as a pixel map in
                      textures/gui/bad_omen.png.json. Any effect can be
                      the omen, vanilla ones included.

    advancements/omen_on_join.json, functions/give_omen.mcfunction
                      A hidden advancement with the tick trigger is earned
                      on a player's first tick in the world, once, and its
                      reward function gives the Bad Omen. Any advancement
                      trigger can hand out the omen the same way: entering
                      a village, killing a mob, sleeping.

    worldintro/raid_example.json, texts/intro.txt
                      A single still page shown the first time a player
                      enters the world, with what to do. Instructions
                      belong on an intro page like this one; the welcome
                      greeting is one short line.

    items/ominous_brew.json
                      A drink that gives the omen for five minutes. It is
                      one way of handing a player the omen; a command, a
                      loot table or another mod's item works as well.

    entities/         The raiders the vanilla game of this version lacks,
                      built as entity variants:
                        Pillager      a skeleton that does not burn in
                                      daylight, with a bow
                        Raid Captain  a named, glowing vindicator that
                                      drops an Ominous Brew, so a won
                                      raid can lead to the next one
                        Axe Thrower   throws its axe, which flies back to
                                      its hand the way a trident does
                        Ravager       a large gray beast that charges and
                                      knocks its target flying
                      A variant keeps everything it is given and gains the
                      raid's march toward the village.

    blocks/village_bell.json
                      The bell. Ring it by right-clicking it: villagers
                      within 48 blocks run indoors and raiders within 48
                      blocks glow for three seconds. Every bell in the
                      village also rings as each wave arrives.

    structures/bell_pavilion.nbt
                      Nothing generates a bell by itself, so the pack
                      builds it into an NBT structure, a small roofed
                      pavilion, and the world template's
                      villageWellStructure stands it in place of the well.
                      Every village this pack makes has exactly one bell,
                      in the middle of the plaza where its streets meet.
                      A village plot in villages/ is the other way to
                      place one, but a plot can be picked more than once.

    functions/raid_won.mcfunction, functions/raid_lost.mcfunction
                      Run as every player near the village when the raid
                      ends.

Raiders break down wooden doors to get at the villagers hiding behind
them, on normal and hard difficulty. Iron doors hold.
