RDPL Raid Example
=================

The 1.12.2 raid example, carried to this version by the forward port and
finished by hand.

Drop the zip into rdploader/ and make a NEW world. Load this pack on its
own: with 'auto' world template selection another pack's template can be
chosen instead of this one.

The world is flat and creative, held at noon on normal difficulty, with one
of the game's villages at spawn and no natural spawns. Everything the pack
adds is in the RDPL Raid Example creative tab.

Starting a raid
---------------

1. Join the world. The first time a player joins they are given Bad Omen
   for five minutes, and they spawn inside the village.
2. A village is where the game keeps its village points, the beds, job
   sites and the bell its villagers claim. Once the player stands among
   them the Bad Omen is taken away, a horn sounds and the Raid bar comes up.
3. For another raid, drink an Ominous Brew inside the village. A Raid
   Captain drops one.
4. Switch to survival (/gamemode survival) if you want to be fought. A
   creative player is never attacked, so staying creative lets you watch.

The game's own Bad Omen starts the game's own raid, which is why the omen
here is the pack's.

The bar fills for fifteen seconds and the first wave arrives from outside
the village. Five waves come, fifteen seconds apart once the one before is
gone. Kill every raider to win: a title, eight emeralds and Hero of the
Village for two minutes. If every villager dies, the village has fallen.

What each part of the pack shows
--------------------------------

    data/raidexample/raids/village_raid.json
                      The raid itself: the omen that starts it, the bar's
                      name and color, the delay between waves, the horn,
                      the bells and the two ending functions. Each wave is
                      a list of groups, and a group names any entity with
                      a count, fixed or a min and max. Vanilla illagers,
                      a witch and the pack's own variants mix freely.

    data/raidexample/potions/bad_omen.json
                      The omen is a potion effect of the pack's own, with
                      its own icon drawn as a pixel map in
                      assets/raidexample/textures/mob_effect/bad_omen.png.json.
                      Any effect can be the omen.

    data/raidexample/advancements/omen_on_join.json,
    data/raidexample/functions/give_omen.mcfunction
                      A hidden advancement with the tick trigger is earned
                      on a player's first tick in the world, once, and its
                      reward function gives the Bad Omen. Any advancement
                      trigger can hand out the omen the same way: entering
                      a village, killing a mob, sleeping.

    data/raidexample/worldintro/raid_example.json,
    assets/raidexample/texts/intro.txt
                      A single still page shown the first time a player
                      enters the world, with what to do. Instructions
                      belong on an intro page like this one; the welcome
                      greeting is one short line.

    data/raidexample/items/ominous_brew.json
                      A drink that gives the omen for five minutes. It is
                      one way of handing a player the omen; a command, a
                      loot table or another mod's item works as well.

    data/raidexample/entities/
                      The raiders, built as entity variants:
                        Pillager      a skeleton that does not burn in
                                      daylight, with a bow
                        Raid Captain  a named, glowing vindicator that
                                      drops an Ominous Brew, so a won
                                      raid can lead to the next one
                        Axe Thrower   throws its axe with a sweep sound,
                                      and the axe flies back to its hand
                                      the way a trident does
                        Ravager       a large gray beast that charges and
                                      knocks its target flying
                      A variant keeps everything it is given and gains the
                      raid's march toward the village.

    data/raidexample/blocks/village_bell.json
    assets/raidexample/blockstates/village_bell.json
                      The bell, a block of type bell, with its own model
                      of posts, a beam and a gold bell. Ring it by using a
                      side of the bell, by redstone or by hitting it with
                      an arrow: it swings away from the side it was struck
                      on, villagers within 32 blocks run indoors, and when
                      raiders are within 32 blocks it resonates, and two
                      seconds later every raider within 48 blocks glows
                      for three. Every bell in the village also rings as
                      each wave arrives, with no need to name it in the
                      raid, which is why the raid here names only the
                      game's minecraft:bell. The blockstate gives the
                      frame for each attachment and facing, sixteen
                      variants in the game's own format, and the swinging
                      part is the separate model village_bell_body. Set
                      "swing" to false in the bell section, and put the
                      bell into the frame models, to draw it all as one
                      still block.

    data/raidexample/worldtemplates/raid_example.json
                      The flat world, its village pinned at the origin
                      with structureAt villages=0,0, the noon lock and the
                      normal difficulty the raiders need to break doors.

    data/raidexample/functions/raid_won.mcfunction,
    data/raidexample/functions/raid_lost.mcfunction
                      Run as every player near the village when the raid
                      ends.

Raiders never hurt or target one another, so a Pillager's stray arrow does
nothing to the vindicator in front of it. They break down wooden doors to
get at the villagers hiding behind them, on normal and hard difficulty.
Iron doors hold.

What changed from 1.12.2
------------------------

The 1.12.2 pack stood its bell in a roofed pavilion that replaced the
village well. The game's villages on this version have no well and already
carry a bell, so the pavilion structure and villageWellStructure are gone
and the raid names the game's minecraft:bell, the pack's own bell needing
no naming. The effect icons moved to textures/mob_effect, where this
version looks for them, and the flat layers name minecraft:grass_block.
