effect @s raidexample:bad_omen 300 0 true
